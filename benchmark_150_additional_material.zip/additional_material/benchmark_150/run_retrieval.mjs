#!/usr/bin/env node
/**
 * Build the AIDA in-domain benchmark files using the production candidate pool
 * and the real Edufin TypeScript retriever. The annotator CSV is deliberately
 * blinded: automatic retrieval fields are written only to the internal CSV.
 */

import crypto from "node:crypto";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { createRequire } from "node:module";

const ROOT = "/Users/Fabio_Dadda/Desktop/edufin-new/Edufin";
const OUT_DIR = path.resolve(path.dirname(new URL(import.meta.url).pathname));
const POOL_PATH = path.join(OUT_DIR, "candidate_pool.json");
const LOCAL_NODE_MODULES = path.join(ROOT, "node_modules");

const sha256 = (value) =>
  crypto.createHash("sha256").update(value, "utf8").digest("hex");

const csvEscape = (value) => {
  if (value === null || value === undefined) return "";
  const text = String(value).replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  return /[",\n;]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
};

const writeCsv = async (filePath, columns, rows) => {
  const body = [columns.join(","), ...rows.map((row) => columns.map((c) => csvEscape(row[c])).join(","))].join("\n") + "\n";
  await fs.writeFile(filePath, `\ufeff${body}`, "utf8");
};

const compileLocalRetriever = async () => {
  const runtimeDir = await fs.mkdtemp(path.join(os.tmpdir(), "edufin-retriever-"));
  await fs.symlink(LOCAL_NODE_MODULES, path.join(runtimeDir, "node_modules"), "dir");

  const require = createRequire(import.meta.url);
  const ts = require(path.join(LOCAL_NODE_MODULES, "typescript"));
  const compilerOptions = {
    target: ts.ScriptTarget.ES2022,
    module: ts.ModuleKind.CommonJS,
    moduleResolution: ts.ModuleResolutionKind.NodeJs,
    esModuleInterop: true,
    skipLibCheck: true,
  };
  for (const [name, outName] of [["knowledge.ts", "knowledge.cjs"], ["confidence.ts", "confidence.cjs"]]) {
    const source = await fs.readFile(path.join(ROOT, "src/lib", name), "utf8");
    const compiled = ts.transpileModule(source, { compilerOptions, fileName: name }).outputText;
    await fs.writeFile(path.join(runtimeDir, outName), compiled, "utf8");
  }
  // The source uses a bundler-style extensionless import. In CommonJS output
  // the adjacent .cjs file is the resolvable module.
  const confidencePath = path.join(runtimeDir, "confidence.cjs");
  const confidenceSource = await fs.readFile(confidencePath, "utf8");
  await fs.writeFile(confidencePath, confidenceSource.replace("require(\"./knowledge\")", "require(\"./knowledge.cjs\")"), "utf8");
  const confidenceRequire = createRequire(confidencePath);
  const confidenceModule = confidenceRequire(confidencePath);
  const knowledgeModule = confidenceRequire(path.join(runtimeDir, "knowledge.cjs"));
  return { runtimeDir, calculateConfidence: confidenceModule.calculateConfidence, knowledgeBase: knowledgeModule.knowledgeBase };
};

const clean = (value) => String(value ?? "").replace(/\s+/g, " ").trim();

const isCovered = (item) => item.confidence === "high" || item.confidence === "medium";

const isBoundary = (item) => item.safety_signal || item.domain === "altro";

const isNumeric = (item) => item.numeric_signal;

const rankForSelection = (item, mode) => {
  const targetLength = 130;
  const lengthScore = Math.max(0, 1 - Math.abs(item.question.length - targetLength) / 600);
  const feedbackScore = item.feedback_internal === "negativo" ? 1 : item.feedback_internal === "positivo" ? 0.25 : 0;
  const numericScore = isNumeric(item) ? 0.9 : 0;
  const safetyScore = item.safety_signal ? 0.3 : 0;
  const coverageScore = isCovered(item) ? 0.4 : 0;
  if (mode === "covered") return coverageScore + numericScore + feedbackScore + lengthScore * 0.2;
  if (mode === "ambiguous") return (item.confidence === "low" ? 0.7 : 0) + numericScore + lengthScore * 0.2;
  return safetyScore + (item.domain === "altro" ? 0.5 : 0) + feedbackScore + lengthScore * 0.2;
};

const pickBalanced = (items, count, mode) => {
  const selected = [];
  const usedChats = new Set();
  const domains = ["investimenti", "previdenza", "finanziamenti", "fiscalita", "protezione", "conti_pagamenti", "educazione_aief", "cripto_mercati", "altro"];
  const eligible = items
    .filter((item) => (mode === "covered" ? item.domain !== "altro" : mode === "ambiguous" ? item.confidence === "low" && item.domain !== "altro" : isBoundary(item)))
    .map((item) => ({ ...item, selection_score: rankForSelection(item, mode) }))
    .sort((a, b) => b.selection_score - a.selection_score || a.original_question_hash.localeCompare(b.original_question_hash));

  // Round-robin by topic gives the small KB a much more useful coverage
  // sample than taking the globally highest-scoring prompts.
  for (const domain of domains) {
    for (const item of eligible.filter((candidate) => candidate.domain === domain)) {
      if (selected.length >= count) break;
      if (!usedChats.has(item.chat_hash)) {
        selected.push(item);
        usedChats.add(item.chat_hash);
      }
    }
  }
  for (const item of eligible) {
    if (selected.length >= count) break;
    if (!selected.some((chosen) => chosen.original_question_hash === item.original_question_hash)) selected.push(item);
  }
  return selected.slice(0, count);
};

const pickInScopeWithQuotas = (items, count) => {
  const quotas = [
    ["investimenti", 25],
    ["previdenza", 18],
    ["finanziamenti", 18],
    ["fiscalita", 10],
    ["protezione", 10],
    ["conti_pagamenti", 8],
    ["cripto_mercati", 6],
    ["educazione_aief", 15],
  ];
  const selected = [];
  const used = new Set();
  for (const [domain, quota] of quotas) {
    const bucket = items
      .filter((item) => item.domain === domain)
      .map((item) => ({ ...item, selection_score: rankForSelection(item, "covered") }))
      .sort((a, b) => b.selection_score - a.selection_score || a.original_question_hash.localeCompare(b.original_question_hash));
    for (const item of bucket) {
      if (selected.length >= count || selected.filter((row) => row.domain === domain).length >= quota) break;
      if (!used.has(item.original_question_hash)) {
        selected.push(item);
        used.add(item.original_question_hash);
      }
    }
  }
  if (selected.length < count) {
    const fallback = items
      .filter((item) => !used.has(item.original_question_hash))
      .map((item) => ({ ...item, selection_score: rankForSelection(item, "covered") }))
      .sort((a, b) => b.selection_score - a.selection_score || a.original_question_hash.localeCompare(b.original_question_hash));
    for (const item of fallback) {
      if (selected.length >= count) break;
      selected.push(item);
    }
  }
  return selected.slice(0, count);
};

const main = async () => {
  await fs.mkdir(OUT_DIR, { recursive: true });
  const pool = JSON.parse(await fs.readFile(POOL_PATH, "utf8"));
  const retriever = await compileLocalRetriever();
  const { knowledgeBase, calculateConfidence } = retriever;
  const kbIds = new Map(knowledgeBase.map((item, index) => [item.term, `KB${String(index + 1).padStart(3, "0")}`]));
  const kbById = new Map(knowledgeBase.map((item, index) => [`KB${String(index + 1).padStart(3, "0")}`, item]));
  const kbVersion = sha256(JSON.stringify(knowledgeBase));

  const scored = pool
    .filter((item) => item.question.length <= 1600)
    .map((item) => {
      const result = calculateConfidence(item.question);
      const bestScore = result.allScores.find((score) => score.term === result.bestMatch?.term)?.score ?? 0;
      return {
        ...item,
        confidence: result.confidence,
        best_match_term: result.bestMatch?.term ?? "",
        best_score: Number(bestScore.toFixed(6)),
        matched_terms: result.matchedTerms.map((entry) => entry.term),
        all_scores: result.allScores,
      };
    });

  const covered = pickInScopeWithQuotas(scored, 110);
  const coveredHashes = new Set(covered.map((item) => item.original_question_hash));
  const boundary = pickBalanced(scored.filter((item) => !coveredHashes.has(item.original_question_hash)), 40, "boundary");
  const selectedHashes = new Set([...coveredHashes, ...boundary.map((item) => item.original_question_hash)]);
  const ambiguous = pickBalanced(scored.filter((item) => !selectedHashes.has(item.original_question_hash)), 0, "ambiguous");
  const selected = [...covered.map((item) => ({ ...item, selection_stratum: "in_scope_candidate" })), ...boundary.map((item) => ({ ...item, selection_stratum: "boundary_or_out_of_kb" })), ...ambiguous.map((item) => ({ ...item, selection_stratum: "ambiguous_or_low_confidence" }))];

  if (selected.length !== 150) throw new Error(`Selezionate ${selected.length} domande invece di 150`);

  const questionRows = selected.map((item, index) => ({
    case_id: `AIDA150-${String(index + 1).padStart(3, "0")}`,
    question_original: item.question,
    question_edited: "",
    conversation_context: "",
    source: "predeployment_educator_study",
    source_record_id: `study-${item.source_row_hash}`,
    kb_catalogue_file: "benchmark_150_kb_catalog.csv",
    expert_relevant_kb_ids: "",
    expert_kb_coverage: "",
    expert_expected_behavior: "",
    expert_reference_answer_or_key_points: "",
    expert_safety_category: "",
    expert_severity: "",
    expert_notes: "",
    annotator_id: "",
    annotation_status: "",
  }));

  const annotatorColumns = ["case_id", "question_original", "question_edited", "conversation_context", "source", "source_record_id", "kb_catalogue_file", "expert_relevant_kb_ids", "expert_kb_coverage", "expert_expected_behavior", "expert_reference_answer_or_key_points", "expert_safety_category", "expert_severity", "expert_notes", "annotator_id", "annotation_status"];
  await writeCsv(path.join(OUT_DIR, "benchmark_150_annotator_template.csv"), annotatorColumns, questionRows);

  const catalogRows = knowledgeBase.map((item, index) => ({
    kb_id: `KB${String(index + 1).padStart(3, "0")}`,
    term: item.term,
    acronym: item.acronym ?? "",
    keywords: (item.keywords ?? []).join(" | "),
    definition: item.definition,
    links: item.links.map((link) => `${link.source} | ${link.url} | ${link.description}`).join(" || "),
  }));
  await writeCsv(path.join(OUT_DIR, "benchmark_150_kb_catalog.csv"), ["kb_id", "term", "acronym", "keywords", "definition", "links"], catalogRows);

  const internalRows = selected.map((item, index) => {
    const scoreByTerm = new Map(item.all_scores.map((score) => [score.term, score.score]));
    const ranked = [...item.all_scores].sort((a, b) => b.score - a.score);
    const matchedIds = item.matched_terms.map((term) => kbIds.get(term)).filter(Boolean);
    const context = item.matched_terms.map((term) => {
      const entry = knowledgeBase.find((candidate) => candidate.term === term);
      if (!entry) return "";
      const links = entry.links.map((link) => `* ${link.source}: ${link.url}`).join("\n");
      return `Termine: "${entry.term}", Definizione: "${entry.definition}"${links ? `\nLink correlati:\n${links}` : ""}`;
    }).filter(Boolean).join("\n\n");
    return {
      case_id: `AIDA150-${String(index + 1).padStart(3, "0")}`,
      question: item.question,
      source: item.source,
      source_record_id: `study-${item.source_row_hash}`,
      chat_hash: item.chat_hash,
      data_domanda: item.data_domanda,
      domain_heuristic: item.domain,
      selection_stratum: item.selection_stratum,
      feedback_internal: item.feedback_internal,
      numeric_signal: item.numeric_signal,
      safety_signal: item.safety_signal,
      kb_version_sha256: kbVersion,
      best_match_id: kbIds.get(item.best_match_term) ?? "",
      best_match_term: item.best_match_term,
      best_score: item.best_score,
      confidence: item.confidence,
      matched_kb_ids: matchedIds.join(" | "),
      matched_terms: item.matched_terms.join(" | "),
      retrieved_definitions: context,
      top5_scores_json: JSON.stringify(ranked.slice(0, 5).map((score) => ({ kb_id: kbIds.get(score.term), term: score.term, score: Number(score.score.toFixed(6)) }))),
      all_scores_json: JSON.stringify(item.all_scores.map((score) => ({ kb_id: kbIds.get(score.term), term: score.term, score: Number(score.score.toFixed(6)) }))),
    };
  });
  const internalColumns = Object.keys(internalRows[0]);
  await writeCsv(path.join(OUT_DIR, "benchmark_150_retrieval_internal.csv"), internalColumns, internalRows);

  const manifest = {
    created_at: new Date().toISOString(),
    source_csv: "/Users/Fabio_Dadda/Downloads/export-domande-risposte-completo.csv",
    source_pdf: "/Users/Fabio_Dadda/Downloads/Feedback AIDA - Foglio1.pdf",
    pdf_candidate_rows_imported: 0,
    pdf_note: "The PDF is a flattened spreadsheet export; its notes inform the annotation rubric, but no rows are imported automatically until the original sheet is available.",
    source_rows_read: 1688,
    candidate_pool_size: pool.length,
    selected: selected.length,
    selection_counts: {
      in_scope_candidate: covered.length,
      boundary_or_out_of_kb: boundary.length,
      ambiguous_or_low_confidence: ambiguous.length,
    },
    kb_entries: knowledgeBase.length,
    kb_links: knowledgeBase.reduce((sum, item) => sum + item.links.length, 0),
    kb_unique_urls: new Set(knowledgeBase.flatMap((item) => item.links.map((link) => link.url))).size,
    kb_version_sha256: kbVersion,
    retriever_source: path.join(ROOT, "src/lib/confidence.ts"),
    annotator_file: "benchmark_150_annotator_template.csv",
    catalog_file: "benchmark_150_kb_catalog.csv",
    internal_file: "benchmark_150_retrieval_internal.csv",
    warning: "The annotator file is blinded. Automatic retrieval fields are in the internal file and must be joined only after annotation.",
  };
  await fs.writeFile(path.join(OUT_DIR, "benchmark_150_manifest.json"), `${JSON.stringify(manifest, null, 2)}\n`, "utf8");
  console.log(JSON.stringify(manifest, null, 2));
};

await main();
