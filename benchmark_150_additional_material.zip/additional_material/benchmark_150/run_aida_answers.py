#!/usr/bin/env python3
"""Run the local Edufin/AIDA flow on the final 150-question gold file.

The script deliberately uses the public tRPC procedures exposed by the local
Edufin checkout.  Each question gets a fresh pseudonymous chat, and the
knowledgeContext returned by the sendMessage mutation is retained so that
educators can judge the generated answer against the evidence actually shown
to AIDA.  A JSONL checkpoint makes the run resumable; the reviewer-facing CSV
is rewritten after every completed case.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import random
import re
import time
import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import httpx


def utc_now() -> str:
    return datetime.now(UTC).isoformat()


def text_sha256(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def clean_error(exc: Exception) -> str:
    value = f"{type(exc).__name__}: {exc}"
    endpoint = os.getenv("AIDA_BASE_URL", "")
    if endpoint:
        value = value.replace(endpoint, "[AIDA_BASE_URL]")
    value = re.sub(r"([?&](?:key|api_key|token)=)[^&\s]+", r"\1[REDACTED]", value)
    return value[:2000]


def unwrap_trpc(payload: Any) -> Any:
    if isinstance(payload, list):
        if len(payload) != 1:
            raise ValueError(f"Risposta batch tRPC inattesa: {len(payload)} elementi")
        payload = payload[0]
    if not isinstance(payload, dict):
        raise TypeError("Risposta tRPC non valida")
    if "error" in payload:
        raise RuntimeError(json.dumps(payload["error"], ensure_ascii=False))
    value: Any = payload
    for key in ("result", "data", "json"):
        if isinstance(value, dict) and key in value:
            value = value[key]
    return value


def csv_escape(value: Any) -> str:
    text = "" if value is None else str(value)
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    if any(ch in text for ch in (",", "\n", '"')):
        return '"' + text.replace('"', '""') + '"'
    return text


CSV_FIELDS = [
    "case_id",
    "question_original",
    "question_edited",
    "conversation_context",
    "source",
    "source_record_id",
    "expert_relevant_kb_ids",
    "expert_kb_coverage",
    "expert_expected_behavior",
    "expert_reference_answer_or_key_points",
    "expert_safety_category",
    "expert_severity",
    "aida_answer",
    "aida_status",
    "aida_error",
    "aida_run_id",
    "aida_attempt",
    "aida_started_at",
    "aida_completed_at",
    "aida_latency_ms",
    "aida_chat_id",
    "aida_message_id",
    "aida_confidence",
    "aida_best_match_id",
    "aida_best_match_term",
    "aida_best_score",
    "aida_matched_kb_ids",
    "aida_matched_terms",
    "aida_retrieved_context",
    "aida_retrieved_context_sha256",
    # Educator fields: intentionally blank until human evaluation.
    "eval_correctness_0_2",
    "eval_completeness_0_2",
    "eval_clarity_0_2",
    "eval_groundedness_0_2",
    "eval_expected_behavior_ok",
    "eval_safety_boundary_ok",
    "eval_escalation_or_abstention_ok",
    "eval_overall_label",
    "eval_error_or_omission",
    "eval_notes",
    "evaluator_id",
    "evaluation_status",
]


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    rows: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.strip():
            rows.append(json.loads(line))
    return rows


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows),
        encoding="utf-8",
    )
    temporary.replace(path)


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8", newline="") as handle:
        handle.write("\ufeff")
        writer = csv.DictWriter(handle, fieldnames=CSV_FIELDS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows({field: row.get(field, "") for field in CSV_FIELDS} for row in rows)
    temporary.replace(path)


def latest_bot_message(chat: dict[str, Any]) -> dict[str, Any]:
    messages = chat.get("messages") or []
    bot_messages = [item for item in messages if item.get("sender") == "bot"]
    if len(bot_messages) < 2:
        raise RuntimeError("AIDA non ha restituito un nuovo messaggio bot")
    return max(
        bot_messages,
        key=lambda item: (item.get("time") or "", item.get("messageId") or 0),
    )


def run_one(
    client: httpx.Client,
    base_url: str,
    question: str,
    *,
    run_id: str,
    case_id: str,
    max_attempts: int,
    timeout_seconds: float,
) -> dict[str, Any]:
    del timeout_seconds  # configured on the shared client
    started_at = utc_now()
    last_error = ""
    for attempt in range(1, max_attempts + 1):
        anon_id = f"benchmark150-{run_id}-{case_id}-{uuid.uuid4().hex[:10]}"
        started = time.perf_counter()
        try:
            query_input = {"json": {"anonymId": anon_id, "newChat": True}}
            response = client.get(
                f"{base_url}/api/trpc/chat.getOrCreateChat",
                params={"input": json.dumps(query_input, ensure_ascii=False)},
            )
            response.raise_for_status()
            chat = unwrap_trpc(response.json())
            if not isinstance(chat, dict) or not chat.get("chatId"):
                raise RuntimeError("Creazione della chat AIDA non riuscita")

            mutation = client.post(
                f"{base_url}/api/trpc/chat.sendMessage",
                json={"json": {"text": question, "anonId": anon_id}},
            )
            mutation.raise_for_status()
            mutation_result = unwrap_trpc(mutation.json())
            if not isinstance(mutation_result, dict):
                raise RuntimeError("Risposta sendMessage AIDA non valida")

            response = client.get(
                f"{base_url}/api/trpc/chat.getOrCreateChat",
                params={
                    "input": json.dumps(
                        {"json": {"anonymId": anon_id, "newChat": False}},
                        ensure_ascii=False,
                    )
                },
            )
            response.raise_for_status()
            completed_chat = unwrap_trpc(response.json())
            if not isinstance(completed_chat, dict):
                raise RuntimeError("Impossibile rileggere la chat AIDA")
            bot = latest_bot_message(completed_chat)
            answer = str(bot.get("text") or "").strip()
            if not answer:
                raise RuntimeError("Risposta AIDA vuota")
            context = str(mutation_result.get("knowledgeContext") or "")
            elapsed = (time.perf_counter() - started) * 1000
            return {
                "aida_status": "ok",
                "aida_error": "",
                "aida_run_id": run_id,
                "aida_attempt": attempt,
                "aida_started_at": started_at,
                "aida_completed_at": utc_now(),
                "aida_latency_ms": round(elapsed, 3),
                "aida_chat_id": completed_chat.get("chatId"),
                "aida_message_id": bot.get("messageId"),
                "aida_answer": answer,
                "aida_retrieved_context": context,
                "aida_retrieved_context_sha256": text_sha256(context),
                "aida_knowledge_context_chars": len(context),
            }
        except Exception as exc:  # failures are retained in the checkpoint
            last_error = clean_error(exc)
            if attempt < max_attempts:
                time.sleep(min(2 ** (attempt - 1) + random.random(), 20.0))
    return {
        "aida_status": "error",
        "aida_error": last_error,
        "aida_run_id": run_id,
        "aida_attempt": max_attempts,
        "aida_started_at": started_at,
        "aida_completed_at": utc_now(),
        "aida_latency_ms": "",
        "aida_chat_id": "",
        "aida_message_id": "",
        "aida_answer": "",
        "aida_retrieved_context": "",
        "aida_retrieved_context_sha256": "",
        "aida_knowledge_context_chars": 0,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=Path("benchmark_150_final_gold.csv"))
    parser.add_argument("--retrieval", type=Path, default=Path("benchmark_150_retrieval_internal.csv"))
    parser.add_argument("--output", type=Path, default=Path("benchmark_150_answers_for_evaluation.csv"))
    parser.add_argument("--checkpoint", type=Path, default=Path("benchmark_150_answers_for_evaluation.jsonl"))
    parser.add_argument("--base-url", default=os.getenv("AIDA_BASE_URL", "http://127.0.0.1:3000"))
    parser.add_argument("--run-id", default="aida-benchmark-150")
    parser.add_argument("--max-attempts", type=int, default=4)
    parser.add_argument("--timeout", type=float, default=240.0)
    args = parser.parse_args()
    if args.max_attempts < 1:
        raise SystemExit("--max-attempts deve essere almeno 1")

    gold_rows = read_csv(args.input)
    retrieval_rows = {row["case_id"]: row for row in read_csv(args.retrieval)}
    if len(gold_rows) != 150:
        raise SystemExit(f"Il final gold contiene {len(gold_rows)} righe, attese 150")
    if set(row["case_id"] for row in gold_rows) - retrieval_rows.keys():
        raise SystemExit("Mancano casi nel retrieval internal")

    checkpoint_rows = read_jsonl(args.checkpoint)
    completed = {row.get("case_id"): row for row in checkpoint_rows if row.get("aida_status") == "ok"}
    all_rows: list[dict[str, Any]] = []
    headers = {"Content-Type": "application/json"}
    with httpx.Client(headers=headers, timeout=args.timeout) as client:
        for index, gold in enumerate(gold_rows, start=1):
            case_id = gold["case_id"]
            base = dict(gold)
            internal = retrieval_rows[case_id]
            base.update(
                {
                    "aida_confidence": internal.get("confidence", ""),
                    "aida_best_match_id": internal.get("best_match_id", ""),
                    "aida_best_match_term": internal.get("best_match_term", ""),
                    "aida_best_score": internal.get("best_score", ""),
                    "aida_matched_kb_ids": internal.get("matched_kb_ids", ""),
                    "aida_matched_terms": internal.get("matched_terms", ""),
                    "eval_correctness_0_2": "",
                    "eval_completeness_0_2": "",
                    "eval_clarity_0_2": "",
                    "eval_groundedness_0_2": "",
                    "eval_expected_behavior_ok": "",
                    "eval_safety_boundary_ok": "",
                    "eval_escalation_or_abstention_ok": "",
                    "eval_overall_label": "",
                    "eval_error_or_omission": "",
                    "eval_notes": "",
                    "evaluator_id": "",
                    "evaluation_status": "",
                }
            )
            if case_id in completed:
                answer_row = completed[case_id]
            else:
                answer_row = run_one(
                    client,
                    args.base_url.rstrip("/"),
                    gold.get("question_original", ""),
                    run_id=args.run_id,
                    case_id=case_id,
                    max_attempts=args.max_attempts,
                    timeout_seconds=args.timeout,
                )
                checkpoint_rows = [row for row in checkpoint_rows if row.get("case_id") != case_id]
                checkpoint_rows.append({"case_id": case_id, **answer_row})
                write_jsonl(args.checkpoint, checkpoint_rows)
            base.update(answer_row)
            all_rows.append(base)
            write_csv(args.output, all_rows)
            print(f"[{index}/150] {case_id}: {base.get('aida_status')}", flush=True)

    ok = sum(row.get("aida_status") == "ok" for row in all_rows)
    print(json.dumps({"run_id": args.run_id, "rows": len(all_rows), "ok": ok, "errors": len(all_rows) - ok, "output": str(args.output), "checkpoint": str(args.checkpoint)}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
