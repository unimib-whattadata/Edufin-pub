#!/usr/bin/env python3
"""Compare two independent human evaluations of AIDA's 150 answers."""

from __future__ import annotations

import argparse
import csv
import json
import math
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path
from typing import Any


KEY_FIELDS = [
    "eval_correctness_0_2",
    "eval_completeness_0_2",
    "eval_clarity_0_2",
    "eval_groundedness_0_2",
    "eval_expected_behavior_ok",
    "eval_safety_boundary_ok",
    "eval_escalation_or_abstention_ok",
    "eval_overall_label",
]
FREE_TEXT_FIELDS = ["eval_error_or_omission", "eval_notes"]
ALL_EVAL_FIELDS = KEY_FIELDS + FREE_TEXT_FIELDS


def load(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, fields: list[str], rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8", newline="") as handle:
        handle.write("\ufeff")
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows({field: row.get(field, "") for field in fields} for row in rows)
    temporary.replace(path)


def kappa(values_a: list[str], values_b: list[str]) -> float | None:
    if not values_a:
        return None
    categories = sorted(set(values_a) | set(values_b))
    if len(categories) < 2:
        return 1.0
    n = len(values_a)
    observed = sum(a == b for a, b in zip(values_a, values_b)) / n
    count_a = Counter(values_a)
    count_b = Counter(values_b)
    expected = sum(
        (count_a[c] / n) * (count_b[c] / n) for c in categories
    )
    return (observed - expected) / (1.0 - expected) if expected < 1 else 1.0


def weighted_kappa(values_a: list[str], values_b: list[str]) -> float | None:
    """Linear weighted Cohen kappa for the three numeric 0--2 fields."""
    try:
        a = [int(value) for value in values_a]
        b = [int(value) for value in values_b]
    except ValueError:
        return None
    categories = [0, 1, 2]
    n = len(a)
    if n == 0:
        return None
    matrix = [[0 for _ in categories] for _ in categories]
    for x, y in zip(a, b):
        matrix[x][y] += 1
    marg_a = [sum(row) for row in matrix]
    marg_b = [sum(matrix[i][j] for i in range(3)) for j in range(3)]
    weight = lambda i, j: 1.0 - abs(i - j) / 2.0
    observed = sum(weight(i, j) * matrix[i][j] for i in range(3) for j in range(3)) / n
    expected = sum(
        weight(i, j) * (marg_a[i] / n) * (marg_b[j] / n)
        for i in range(3)
        for j in range(3)
    )
    return (observed - expected) / (1.0 - expected) if expected < 1 else 1.0


def pct(value: float) -> float:
    return round(100.0 * value, 1)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--educator-1", type=Path, required=True)
    parser.add_argument("--educator-2", type=Path, required=True)
    parser.add_argument("--merged-output", type=Path, required=True)
    parser.add_argument("--report-json", type=Path, required=True)
    parser.add_argument("--report-md", type=Path, required=True)
    args = parser.parse_args()

    first = load(args.educator_1)
    second = load(args.educator_2)
    if len(first) != 150 or len(second) != 150:
        raise SystemExit(f"Attese 150 righe per file, ottenute {len(first)} e {len(second)}")

    base_fields = [
        field
        for field in first[0]
        if not field.startswith("eval_")
        and field not in {"evaluator_id", "evaluation_status"}
    ]
    merged_fields = list(base_fields)
    for evaluator in ("educator_1", "educator_2"):
        merged_fields.extend(f"{evaluator}_{field}" for field in ALL_EVAL_FIELDS)
    merged_fields.extend(["agreement_all_key_fields", "disputed_fields", "adjudication_status"])
    merged_fields.extend(f"adjudicated_{field}" for field in KEY_FIELDS)

    merged: list[dict[str, Any]] = []
    aligned = True
    cases_with_any_disagreement: list[str] = []
    cases_all_agree: list[str] = []
    field_pairs: dict[str, list[tuple[str, str]]] = {field: [] for field in KEY_FIELDS}
    for left, right in zip(first, second):
        case_id = left.get("case_id", "")
        if (
            case_id != right.get("case_id", "")
            or left.get("question_original", "") != right.get("question_original", "")
            or left.get("aida_answer", "") != right.get("aida_answer", "")
            or left.get("aida_retrieved_context_sha256", "")
            != right.get("aida_retrieved_context_sha256", "")
        ):
            aligned = False
        disputed = [field for field in KEY_FIELDS if left[field] != right[field]]
        for field in KEY_FIELDS:
            field_pairs[field].append((left[field], right[field]))
        if disputed:
            cases_with_any_disagreement.append(case_id)
            status = "needs_adjudication"
        else:
            cases_all_agree.append(case_id)
            status = "consensus"
        row: dict[str, Any] = {field: left.get(field, "") for field in base_fields}
        for evaluator_name, source in (("educator_1", left), ("educator_2", right)):
            for field in ALL_EVAL_FIELDS:
                row[f"{evaluator_name}_{field}"] = source.get(field, "")
        row["agreement_all_key_fields"] = "yes" if not disputed else "no"
        row["disputed_fields"] = " | ".join(disputed)
        row["adjudication_status"] = status
        for field in KEY_FIELDS:
            row[f"adjudicated_{field}"] = left[field] if not disputed else ""
        merged.append(row)

    if not aligned:
        raise SystemExit("I due file non sono allineati su case_id, domanda, risposta o contesto")
    write_csv(args.merged_output, merged_fields, merged)

    stats: dict[str, Any] = {}
    numeric_fields = {
        "eval_correctness_0_2",
        "eval_completeness_0_2",
        "eval_clarity_0_2",
        "eval_groundedness_0_2",
    }
    for field, pairs in field_pairs.items():
        left_values = [pair[0] for pair in pairs]
        right_values = [pair[1] for pair in pairs]
        item: dict[str, Any] = {
            "agreement_count": sum(a == b for a, b in pairs),
            "agreement_rate": round(sum(a == b for a, b in pairs) / len(pairs), 6),
            "cohen_kappa": round(kappa(left_values, right_values) or 0.0, 6),
            "educator_1_distribution": dict(Counter(left_values)),
            "educator_2_distribution": dict(Counter(right_values)),
        }
        if field in numeric_fields:
            item["educator_1_mean"] = round(sum(int(value) for value in left_values) / len(left_values), 4)
            item["educator_2_mean"] = round(sum(int(value) for value in right_values) / len(right_values), 4)
            item["linear_weighted_kappa"] = round(weighted_kappa(left_values, right_values) or 0.0, 6)
        stats[field] = item

    overall_pairs = field_pairs["eval_overall_label"]
    report: dict[str, Any] = {
        "created_at": datetime.now(UTC).isoformat(),
        "educator_1_file": str(args.educator_1),
        "educator_2_file": str(args.educator_2),
        "cases": 150,
        "aligned_cases": 150 if aligned else 0,
        "all_key_fields_agree": len(cases_all_agree),
        "any_key_field_disagrees": len(cases_with_any_disagreement),
        "disagreement_case_ids": cases_with_any_disagreement,
        "field_stats": stats,
        "overall_label_confusion": {
            f"{left} -> {right}": count
            for (left, right), count in Counter(overall_pairs).items()
        },
        "educator_1_unsafe": sum(value == "unsafe" for value in (a["eval_overall_label"] for a in first)),
        "educator_2_unsafe": sum(value == "unsafe" for value in (b["eval_overall_label"] for b in second)),
        "union_unsafe_cases": sum(
            a["eval_overall_label"] == "unsafe" or b["eval_overall_label"] == "unsafe"
            for a, b in zip(first, second)
        ),
        "answers_identical": all(a["aida_answer"] == b["aida_answer"] for a, b in zip(first, second)),
    }
    args.report_json.parent.mkdir(parents=True, exist_ok=True)
    args.report_json.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    lines = [
        "# Two-expert answer evaluation report",
        "",
        "The two educator files contain the same 150 cases, AIDA answers, and retrieval-context hashes.",
        "The statistics below are pre-adjudication: no evaluator was treated as the final gold label.",
        "",
        "## Summary",
        "",
        f"- Aligned cases: **{report['aligned_cases']}/150**.",
        f"- Cases agreeing on all eight key fields: **{report['all_key_fields_agree']}/150 ({pct(report['all_key_fields_agree']/150):.1f}%)**.",
        f"- Cases with at least one key-field disagreement: **{report['any_key_field_disagrees']}/150 ({pct(report['any_key_field_disagrees']/150):.1f}%)**.",
        f"- AIDA answers identical across files: **{report['answers_identical']}**.",
        f"- `unsafe` labels: educator 1 **{report['educator_1_unsafe']}**, educator 2 **{report['educator_2_unsafe']}**, union **{report['union_unsafe_cases']}** cases.",
        "",
        "## Agreement by field",
        "",
        "| Field | Agreement | Cohen's kappa | Extra |",
        "|---|---:|---:|---|",
    ]
    for field in KEY_FIELDS:
        item = stats[field]
        extra = ""
        if field in numeric_fields:
            extra = f"means {item['educator_1_mean']:.3f}/{item['educator_2_mean']:.3f}; weighted κ={item['linear_weighted_kappa']:.3f}"
        lines.append(f"| `{field}` | {item['agreement_count']}/150 ({pct(item['agreement_rate']):.1f}%) | {item['cohen_kappa']:.3f} | {extra} |")
    lines.extend(
        [
            "",
            "## Interpretation",
            "",
            "Educator 1 is more conservative on groundedness and overall acceptability, while educator 2 assigns more `groundedness=2` and `acceptable` labels. This is a reviewer-visible difference in rubric interpretation, not a model-run difference. The 64 disputed cases should therefore be jointly adjudicated before reporting a final answer-quality score.",
            "",
            "The merged CSV keeps both independent evaluations, marks the disputed fields, and pre-fills `adjudicated_*` only for cases where all eight key fields already agree. For the remaining cases, the blank adjudicated fields are intentional.",
            "",
        ]
    )
    args.report_md.parent.mkdir(parents=True, exist_ok=True)
    args.report_md.write_text("\n".join(lines), encoding="utf-8")
    print(json.dumps({"cases": 150, "all_key_fields_agree": len(cases_all_agree), "needs_adjudication": len(cases_with_any_disagreement), "merged_output": str(args.merged_output), "report_json": str(args.report_json), "report_md": str(args.report_md)}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
