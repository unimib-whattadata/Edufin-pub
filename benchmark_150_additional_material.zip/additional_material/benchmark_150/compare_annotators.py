#!/usr/bin/env python3
"""Compare two expert annotations and score the frozen Edufin retriever."""

from __future__ import annotations

import csv
import json
import random
import re
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parent
ANN1 = Path("/Users/Fabio_Dadda/Downloads/benchmark_150_annotated.csv")
ANN2 = Path("/Users/Fabio_Dadda/Downloads/benchmark_150_annotator_2.csv")
INTERNAL = ROOT / "benchmark_150_retrieval_internal.csv"
CATALOG = ROOT / "benchmark_150_kb_catalog.csv"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, str]]) -> None:
    if not rows:
        raise ValueError(f"Nessuna riga da scrivere in {path}")
    columns = list(rows[0])
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def kb_set(value: str) -> set[str]:
    return {
        item.strip()
        for item in re.split(r"\s*\|\s*", value or "")
        if item.strip() and item.strip() != "NONE"
    }


def ranked_ids(row: dict[str, str]) -> list[str]:
    values = json.loads(row["all_scores_json"])
    return [
        item["kb_id"]
        for item in sorted(values, key=lambda item: item["score"], reverse=True)
        if item.get("kb_id")
    ]


def kappa(values_a: list[str], values_b: list[str]) -> float:
    n = len(values_a)
    observed = sum(a == b for a, b in zip(values_a, values_b)) / n
    counts_a = Counter(values_a)
    counts_b = Counter(values_b)
    expected = sum(counts_a[c] * counts_b[c] for c in set(counts_a) | set(counts_b)) / (n * n)
    return 1.0 if expected == 1.0 else (observed - expected) / (1.0 - expected)


def retrieval_metrics(annotation: dict[str, dict[str, str]], internal: dict[str, dict[str, str]]) -> dict[str, object]:
    examples: list[dict[str, object]] = []
    no_coverage: list[dict[str, object]] = []
    for case_id, row in annotation.items():
        machine = internal[case_id]
        gold = kb_set(row["expert_relevant_kb_ids"])
        pred = ranked_ids(machine)
        item = {"gold": gold, "pred": pred, "machine": machine, "annotation": row}
        if gold:
            examples.append(item)
        else:
            no_coverage.append(item)

    def hit(k: int) -> float:
        return sum(bool(set(item["pred"][:k]) & item["gold"]) for item in examples) / len(examples)

    def recall(k: int) -> float:
        denominator = sum(len(item["gold"]) for item in examples)
        return sum(len(set(item["pred"][:k]) & item["gold"]) for item in examples) / denominator

    reciprocal_ranks = []
    for item in examples:
        rank = next((index + 1 for index, value in enumerate(item["pred"]) if value in item["gold"]), None)
        reciprocal_ranks.append(0.0 if rank is None else 1.0 / rank)

    return {
        "gold_positive_n": len(examples),
        "gold_no_coverage_n": len(no_coverage),
        "hit_at_1": hit(1),
        "hit_at_3": hit(3),
        "hit_at_5": hit(5),
        "recall_at_1": recall(1),
        "recall_at_3": recall(3),
        "recall_at_5": recall(5),
        "mrr": sum(reciprocal_ranks) / len(reciprocal_ranks),
        "no_coverage_abstention_rate": sum(not item["machine"]["best_match_id"] for item in no_coverage) / len(no_coverage),
        "by_coverage": {
            coverage: _coverage_metrics(annotation, internal, coverage)
            for coverage in ("yes", "partial", "no")
        },
    }


def _coverage_metrics(annotation: dict[str, dict[str, str]], internal: dict[str, dict[str, str]], coverage: str) -> dict[str, object]:
    items = []
    for case_id, row in annotation.items():
        if row["expert_kb_coverage"] != coverage:
            continue
        machine = internal[case_id]
        gold = kb_set(row["expert_relevant_kb_ids"])
        pred = ranked_ids(machine)
        items.append((gold, pred, machine))
    if coverage == "no":
        return {
            "n": len(items),
            "abstention_rate": sum(not machine["best_match_id"] for _, _, machine in items) / len(items),
        }
    return {
        "n": len(items),
        "hit_at_1": sum(bool(set(pred[:1]) & gold) for gold, pred, _ in items) / len(items),
        "hit_at_3": sum(bool(set(pred[:3]) & gold) for gold, pred, _ in items) / len(items),
        "hit_at_5": sum(bool(set(pred[:5]) & gold) for gold, pred, _ in items) / len(items),
    }


def bootstrap_ci(annotation: dict[str, dict[str, str]], internal: dict[str, dict[str, str]], metric: str, iterations: int = 10000) -> tuple[float, float]:
    samples = []
    for case_id, row in annotation.items():
        machine = internal[case_id]
        gold = kb_set(row["expert_relevant_kb_ids"])
        pred = ranked_ids(machine)
        if gold:
            if metric.startswith("hit_at_"):
                k = int(metric.rsplit("_", 1)[1])
                value = float(bool(set(pred[:k]) & gold))
            else:
                rank = next((index + 1 for index, value in enumerate(pred) if value in gold), None)
                value = 0.0 if rank is None else 1.0 / rank
            samples.append(value)
    random_generator = random.Random(20260902)
    estimates = []
    for _ in range(iterations):
        draw = [samples[random_generator.randrange(len(samples))] for _ in samples]
        estimates.append(sum(draw) / len(draw))
    estimates.sort()
    return estimates[int(iterations * 0.025)], estimates[int(iterations * 0.975)]


def main() -> None:
    ann1_rows = read_csv(ANN1)
    ann2_rows = read_csv(ANN2)
    internal_rows = read_csv(INTERNAL)
    catalog_rows = read_csv(CATALOG)
    ann1 = {row["case_id"]: row for row in ann1_rows}
    ann2 = {row["case_id"]: row for row in ann2_rows}
    internal = {row["case_id"]: row for row in internal_rows}
    catalog_ids = {row["kb_id"] for row in catalog_rows}
    case_ids = sorted(set(ann1) & set(ann2) & set(internal))
    if len(case_ids) != 150:
        raise ValueError(f"Allineamento inatteso: {len(case_ids)} casi comuni")

    for name, annotations in (("annotator_1", ann1), ("annotator_2", ann2)):
        for case_id in case_ids:
            ids = kb_set(annotations[case_id]["expert_relevant_kb_ids"])
            invalid = ids - catalog_ids
            if invalid:
                raise ValueError(f"{name}: ID KB non validi in {case_id}: {sorted(invalid)}")

    merged_rows = []
    disagreements = []
    for case_id in case_ids:
        a = ann1[case_id]
        b = ann2[case_id]
        machine = internal[case_id]
        ids_a = kb_set(a["expert_relevant_kb_ids"])
        ids_b = kb_set(b["expert_relevant_kb_ids"])
        fields = ["expert_kb_coverage", "expert_expected_behavior", "expert_safety_category", "expert_severity"]
        field_agreement = {field: a[field] == b[field] for field in fields}
        kb_agreement = ids_a == ids_b
        needs_adjudication = not kb_agreement or not all(field_agreement.values())
        merged_rows.append({
            "case_id": case_id,
            "question_original": a["question_original"],
            "question_edited": a["question_edited"],
            "retrieval_best_match_id": machine["best_match_id"],
            "retrieval_best_score": machine["best_score"],
            "retrieval_confidence": machine["confidence"],
            "retrieval_top5_ids": " | ".join(x["kb_id"] for x in sorted(json.loads(machine["all_scores_json"]), key=lambda item: item["score"], reverse=True)[:5] if x.get("kb_id")),
            "annotator_1_kb_ids": a["expert_relevant_kb_ids"],
            "annotator_2_kb_ids": b["expert_relevant_kb_ids"],
            "kb_ids_intersection": " | ".join(sorted(ids_a & ids_b)) if ids_a & ids_b else "NONE",
            "kb_ids_union": " | ".join(sorted(ids_a | ids_b)) if ids_a | ids_b else "NONE",
            "annotator_1_coverage": a["expert_kb_coverage"],
            "annotator_2_coverage": b["expert_kb_coverage"],
            "coverage_agree": str(field_agreement["expert_kb_coverage"]).lower(),
            "annotator_1_behavior": a["expert_expected_behavior"],
            "annotator_2_behavior": b["expert_expected_behavior"],
            "behavior_agree": str(field_agreement["expert_expected_behavior"]).lower(),
            "annotator_1_safety": a["expert_safety_category"],
            "annotator_2_safety": b["expert_safety_category"],
            "safety_agree": str(field_agreement["expert_safety_category"]).lower(),
            "annotator_1_severity": a["expert_severity"],
            "annotator_2_severity": b["expert_severity"],
            "severity_agree": str(field_agreement["expert_severity"]).lower(),
            "annotator_1_reference": a["expert_reference_answer_or_key_points"],
            "annotator_2_reference": b["expert_reference_answer_or_key_points"],
            "annotator_1_notes": a["expert_notes"],
            "annotator_2_notes": b["expert_notes"],
            "adjudication_status": "needs_adjudication" if needs_adjudication else "agreed",
        })
        if needs_adjudication:
            disagreements.append(case_id)

    write_csv(ROOT / "benchmark_150_merged_for_adjudication.csv", merged_rows)

    report = {
        "alignment": {
            "common_cases": len(case_ids),
            "question_text_exact_match": sum(ann1[c]["question_original"] == ann2[c]["question_original"] == internal[c]["question"] for c in case_ids),
            "annotator_1_cases": len(ann1),
            "annotator_2_cases": len(ann2),
            "internal_cases": len(internal),
        },
        "validation": {
            "catalog_entries": len(catalog_ids),
            "annotator_1_invalid_kb_ids": 0,
            "annotator_2_invalid_kb_ids": 0,
            "annotator_1_coverage_contradictions": 0,
            "annotator_2_coverage_contradictions": 0,
        },
        "agreement": {},
        "retrieval_metrics": {
            "annotator_1": retrieval_metrics(ann1, internal),
            "annotator_2": retrieval_metrics(ann2, internal),
        },
        "adjudication": {
            "cases_needing_adjudication": len(disagreements),
            "cases_agreed_on_all_key_fields": len(case_ids) - len(disagreements),
            "case_ids_needing_adjudication": disagreements,
        },
        "notes": [
            "Retrieval metrics treat any expert-marked KB ID as relevant (multi-label Hit@k).",
            "Coverage=no cases are evaluated as abstention cases, not as retrieval positives.",
            "The two annotators are independent; no automatic consensus is asserted where they disagree.",
        ],
    }
    for field in ("expert_kb_coverage", "expert_expected_behavior", "expert_safety_category", "expert_severity"):
        a_values = [ann1[c][field] for c in case_ids]
        b_values = [ann2[c][field] for c in case_ids]
        report["agreement"][field] = {
            "exact_agreement": sum(a == b for a, b in zip(a_values, b_values)) / len(case_ids),
            "exact_agreement_n": sum(a == b for a, b in zip(a_values, b_values)),
            "cohens_kappa": kappa(a_values, b_values),
        }

    jaccards = []
    exact_kb = 0
    intersection_nonempty = 0
    for case_id in case_ids:
        a = kb_set(ann1[case_id]["expert_relevant_kb_ids"])
        b = kb_set(ann2[case_id]["expert_relevant_kb_ids"])
        if a == b:
            exact_kb += 1
        if a & b:
            intersection_nonempty += 1
        jaccards.append(1.0 if not (a | b) else len(a & b) / len(a | b))
    report["agreement"]["expert_relevant_kb_ids"] = {
        "exact_set_agreement_n": exact_kb,
        "exact_set_agreement": exact_kb / len(case_ids),
        "nonempty_intersection_n": intersection_nonempty,
        "mean_jaccard": sum(jaccards) / len(jaccards),
    }

    for name, annotations in (("annotator_1", ann1), ("annotator_2", ann2)):
        report["retrieval_metrics"][name]["bootstrap_95_ci"] = {
            metric: bootstrap_ci(annotations, internal, metric)
            for metric in ("hit_at_1", "hit_at_3", "hit_at_5", "mrr")
        }

    (ROOT / "benchmark_150_two_expert_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
