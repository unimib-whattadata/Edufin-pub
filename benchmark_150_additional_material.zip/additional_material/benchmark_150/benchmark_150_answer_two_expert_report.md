# Two-expert answer evaluation report

The two educator files contain the same 150 cases, AIDA answers, and retrieval-context hashes.
The statistics below are pre-adjudication: no evaluator was treated as the final gold label.

## Summary

- Aligned cases: **150/150**.
- Cases agreeing on all eight key fields: **86/150 (57.3%)**.
- Cases with at least one key-field disagreement: **64/150 (42.7%)**.
- AIDA answers identical across files: **True**.
- `unsafe` labels: educator 1 **4**, educator 2 **3**, union **4** cases.

## Agreement by field

| Field | Agreement | Cohen's kappa | Extra |
|---|---:|---:|---|
| `eval_correctness_0_2` | 140/150 (93.3%) | 0.877 | means 1.473/1.540; weighted κ=0.895 |
| `eval_completeness_0_2` | 150/150 (100.0%) | 1.000 | means 1.300/1.300; weighted κ=1.000 |
| `eval_clarity_0_2` | 136/150 (90.7%) | 0.545 | means 1.933/1.840; weighted κ=0.545 |
| `eval_groundedness_0_2` | 122/150 (81.3%) | 0.710 | means 0.853/1.040; weighted κ=0.758 |
| `eval_expected_behavior_ok` | 149/150 (99.3%) | 0.978 |  |
| `eval_safety_boundary_ok` | 145/150 (96.7%) | 0.690 |  |
| `eval_escalation_or_abstention_ok` | 149/150 (99.3%) | 0.978 |  |
| `eval_overall_label` | 129/150 (86.0%) | 0.735 |  |

## Interpretation

Educator 1 is more conservative on groundedness and overall acceptability, while educator 2 assigns more `groundedness=2` and `acceptable` labels. This is a reviewer-visible difference in rubric interpretation, not a model-run difference. The 64 disputed cases should therefore be jointly adjudicated before reporting a final answer-quality score.

The merged CSV keeps both independent evaluations, marks the disputed fields, and pre-fills `adjudicated_*` only for cases where all eight key fields already agree. For the remaining cases, the blank adjudicated fields are intentional.
