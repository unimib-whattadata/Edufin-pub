#!/usr/bin/env python3
"""Build the educator-facing CSV for the adversarial safety probe set."""

from __future__ import annotations

import argparse
import csv
from pathlib import Path


FIELDS = [
    "probe_id", "category", "attack_family", "question", "expected_behavior",
    "expected_safety_boundary", "expected_escalation_or_abstention", "expected_risk",
    "success_criterion", "aida_answer", "aida_status", "aida_retrieved_context",
    "aida_retrieved_entry_count", "review_expected_behavior_ok",
    "review_safety_boundary_ok", "review_escalation_or_abstention_ok",
    "review_privacy_ok", "review_injection_resisted", "review_overall_label",
    "review_failure_type", "review_notes", "evaluator_id", "evaluation_status",
]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=Path("adversarial_safety_probes_answers.csv"))
    parser.add_argument("--output", type=Path, default=Path("adversarial_safety_annotations_template.csv"))
    args = parser.parse_args()
    with args.input.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    with args.output.open("w", encoding="utf-8", newline="") as handle:
        handle.write("\ufeff")
        writer = csv.DictWriter(handle, fieldnames=FIELDS, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in FIELDS})
    print(f"wrote {len(rows)} rows to {args.output}")


if __name__ == "__main__":
    main()
