#!/usr/bin/env node
/**
 * Run post-hoc retriever ablations and confidence-threshold sensitivity on the
 * adjudicated 150-question gold file. No generation call is made. The full
 * configuration mirrors Edufin/src/lib/confidence.ts; the other rows disable
 * one feature group at a time while keeping the questions, KB, and labels
 * fixed.
 */

import crypto from "node:crypto";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { createRequire } from "node:module";

const ROOT = "/Users/Fabio_Dadda/Desktop/edufin-new/Edufin";
const OUT_DIR = path.resolve(path.dirname(new URL(import.meta.url).pathname));
const GOLD_PATH = path.join(OUT_DIR, "benchmark_150_final_gold.csv");
const LOCAL_NODE_MODULES = path.join(ROOT, "node_modules");

const sha256 = (value) => crypto.createHash("sha256").update(value).digest("hex");

const csvEscape = (value) => {
  if (value === null || value === undefined) return "";
  const text = String(value).replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  return /[",\n;]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
};

const writeCsv = async (filePath, columns, rows) => {
  const body = [columns.join(","), ...rows.map((row) => columns.map((column) => csvEscape(row[column])).join(","))].join("\n") + "\n";
  await fs.writeFile(filePath, `\ufeff${body}`, "utf8");
};

const parseCsv = (text) => {
  const rows = [];
  let row = [];
  let field = "";
  let quoted = false;
  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    if (quoted) {
      if (char === '"' && text[index + 1] === '"') {
        field += '"';
        index += 1;
      } else if (char === '"') {
        quoted = false;
      } else {
        field += char;
      }
    } else if (char === '"') {
      quoted = true;
    } else if (char === ",") {
      row.push(field);
      field = "";
    } else if (char === "\n") {
      row.push(field.replace(/\r$/, ""));
      if (row.some((value) => value.length > 0)) rows.push(row);
      row = [];
      field = "";
    } else {
      field += char;
    }
  }
  if (field.length > 0 || row.length > 0) {
    row.push(field.replace(/\r$/, ""));
    if (row.some((value) => value.length > 0)) rows.push(row);
  }
  if (rows.length === 0) return [];
  const headers = rows[0].map((header) => header.replace(/^\ufeff/, ""));
  return rows.slice(1).map((values) => Object.fromEntries(headers.map((header, index) => [header, values[index] ?? ""])));
};

const compileKnowledge = async () => {
  const runtimeDir = await fs.mkdtemp(path.join(os.tmpdir(), "edufin-ablation-"));
  await fs.symlink(LOCAL_NODE_MODULES, path.join(runtimeDir, "node_modules"), "dir");
  const require = createRequire(import.meta.url);
  const ts = require(path.join(LOCAL_NODE_MODULES, "typescript"));
  const compilerOptions = {
    target: ts.ScriptTarget.ES2022,
    module: ts.ModuleKind.CommonJS,
    moduleResolution: ts.ModuleResolutionKind.NodeJs,
    esModuleInterop: true,
    skipLibCheck: true,
  };
  const source = await fs.readFile(path.join(ROOT, "src/lib", "knowledge.ts"), "utf8");
  const compiled = ts.transpileModule(source, { compilerOptions, fileName: "knowledge.ts" }).outputText;
  const knowledgePath = path.join(runtimeDir, "knowledge.cjs");
  await fs.writeFile(knowledgePath, compiled, "utf8");
  return createRequire(knowledgePath)(knowledgePath).knowledgeBase;
};

const clean = (value) => String(value ?? "").replace(/\s+/g, " ").trim();

const STOP_WORDS = new Set([
  "a", "ad", "al", "allo", "ai", "agli", "all", "alla", "alle", "anche", "che", "chi", "con", "come", "cui", "da", "dal", "dallo", "dai", "dagli", "dalla", "dalle", "dei", "degli", "del", "della", "delle", "di", "dove", "e", "ed", "gli", "ha", "hai", "ho", "i", "il", "in", "io", "la", "le", "lo", "ma", "mi", "ne", "nel", "nella", "nelle", "nello", "non", "o", "per", "piu", "quale", "quali", "quando", "quanto", "se", "sei", "sia", "sono", "su", "tra", "un", "una", "uno", "voi",
]);

const normalizeText = (text) => String(text ?? "")
  .toLowerCase()
  .normalize("NFD")
  .replace(/[\u0300-\u036f]/g, "")
  .replace(/[’']/g, " ")
  .replace(/[^a-z0-9\s]/g, " ")
  .replace(/\s+/g, " ")
  .trim();

const unique = (words) => [...new Set(words)];

const getSignificantWords = (text) => {
  const normalized = normalizeText(text);
  if (!normalized) return [];
  return unique(normalized.split(" ").filter((word) => word.length >= 3 && !STOP_WORDS.has(word)));
};

const containsNormalizedPhrase = (text, phrase) => Boolean(text && phrase && text.includes(phrase));

const makeScorer = (knowledgeBase, options = {}) => {
  const { compareTwoStrings } = createRequire(import.meta.url)(path.join(LOCAL_NODE_MODULES, "string-similarity"));
  const useTokenSimilarity = options.useTokenSimilarity ?? true;
  const useContainmentBonuses = options.useContainmentBonuses ?? true;
  const useAcronymBonuses = options.useAcronymBonuses ?? true;
  const useKeywordBonuses = options.useKeywordBonuses ?? true;
  const useDefinitionBonuses = options.useDefinitionBonuses ?? true;
  const lowFloor = options.lowFloor ?? 0.22;
  const mediumThreshold = options.mediumThreshold ?? 0.42;
  const highThreshold = options.highThreshold ?? 0.70;

  const isWordMatch = (inputWord, targetWord) => {
    if (inputWord === targetWord) return true;
    if (
      inputWord.length >= 4 &&
      targetWord.length >= 4 &&
      (targetWord.includes(inputWord) || inputWord.includes(targetWord))
    ) return true;
    return useTokenSimilarity && compareTwoStrings(inputWord, targetWord) >= 0.75;
  };

  const inputCoverage = (inputWords, targetWords) => {
    if (inputWords.length === 0 || targetWords.length === 0) return 0;
    const matched = inputWords.filter((input) => targetWords.some((target) => isWordMatch(input, target)));
    return matched.length / inputWords.length;
  };

  const balancedOverlap = (inputWords, targetWords) => {
    if (inputWords.length === 0 || targetWords.length === 0) return 0;
    const matched = inputWords.filter((input) => targetWords.some((target) => isWordMatch(input, target)));
    if (matched.length === 0) return 0;
    const precision = matched.length / inputWords.length;
    const recall = matched.length / targetWords.length;
    return (2 * precision * recall) / (precision + recall);
  };

  const score = (question) => {
    const normalizedQuestion = normalizeText(question);
    const questionWords = getSignificantWords(question);
    const scored = knowledgeBase.map((item, kbIndex) => {
      const normalizedTerm = normalizeText(item.term);
      const termWords = getSignificantWords(item.term);
      const termPhraseScore = compareTwoStrings(normalizedQuestion, normalizedTerm);
      const termTokenScore = balancedOverlap(questionWords, termWords);
      let value = termPhraseScore * 0.55 + termTokenScore * 0.45;

      if (useContainmentBonuses && containsNormalizedPhrase(normalizedQuestion, normalizedTerm)) value += 0.25;
      if (useContainmentBonuses && normalizedQuestion.length >= 6 && containsNormalizedPhrase(normalizedTerm, normalizedQuestion)) value += 0.10;

      if (useAcronymBonuses && item.acronym) {
        const normalizedAcronym = normalizeText(item.acronym);
        const acronymWords = getSignificantWords(item.acronym);
        const acronymPhraseScore = compareTwoStrings(normalizedQuestion, normalizedAcronym);
        const acronymTokenScore = balancedOverlap(questionWords, acronymWords);
        value = Math.max(value, acronymPhraseScore * 0.55 + acronymTokenScore * 0.45);
        if (containsNormalizedPhrase(normalizedQuestion, normalizedAcronym) || questionWords.includes(normalizedAcronym)) value += 0.25;
      }

      if (useKeywordBonuses && item.keywords && item.keywords.length > 0) {
        const keywordWords = getSignificantWords(item.keywords.join(" "));
        const keywordInputCoverage = inputCoverage(questionWords, keywordWords);
        const keywordPhraseScore = Math.max(...item.keywords.map((keyword) => compareTwoStrings(normalizedQuestion, normalizeText(keyword))));
        value += keywordInputCoverage * 0.35 + keywordPhraseScore * 0.15;
        if (item.keywords.some((keyword) => containsNormalizedPhrase(normalizedQuestion, normalizeText(keyword)))) value += 0.15;
      }

      if (useDefinitionBonuses) {
        const definitionWords = getSignificantWords(item.definition);
        value += inputCoverage(questionWords, definitionWords) * 0.18;
        const normalizedDefinition = normalizeText(item.definition);
        if (normalizedQuestion.length >= 8 && containsNormalizedPhrase(normalizedDefinition, normalizedQuestion)) value += 0.20;
      }

      return { kbIndex, term: item.term, score: Math.min(value, 1.0) };
    });

    const ranked = [...scored].sort((a, b) => b.score - a.score || a.kbIndex - b.kbIndex);
    const best = ranked[0];
    let confidence = "low";
    let selected = [];
    if (best && best.score >= lowFloor) {
      if (best.score >= highThreshold) {
        confidence = "high";
        const cutoff = Math.max(highThreshold * 0.85, best.score * 0.82);
        selected = ranked.filter((item) => item.score >= cutoff).slice(0, 5);
      } else if (best.score >= mediumThreshold) {
        confidence = "medium";
        const cutoff = Math.max(mediumThreshold * 0.8, best.score * 0.78);
        selected = ranked.filter((item) => item.score >= cutoff).slice(0, 4);
      } else {
        const cutoff = Math.max(lowFloor, best.score * 0.9);
        selected = ranked.filter((item) => item.score >= cutoff).slice(0, 2);
      }
      if (selected.length === 0) selected = [best];
    }
    return { ranked, bestScore: best?.score ?? 0, confidence, selected };
  };

  return { score };
};

const kbId = (index) => `KB${String(index + 1).padStart(3, "0")}`;

const parseIds = (value) => new Set(clean(value).split(/\s*\|\s*/).filter((id) => id && id !== "NONE"));

const metricRow = (variant, cases, options = {}) => {
  const scorer = options.scorer;
  const outputs = cases.map((item) => ({ ...item, result: scorer.score(item.question_original) }));
  const positive = outputs.filter((item) => item.gold.size > 0);
  const noCoverage = outputs.filter((item) => item.gold.size === 0);
  const hit = (k) => positive.filter((item) => item.result.ranked.slice(0, k).some((candidate) => item.gold.has(kbId(candidate.kbIndex)))).length / positive.length;
  const recall = (k) => positive.reduce((sum, item) => sum + item.result.ranked.slice(0, k).filter((candidate) => item.gold.has(kbId(candidate.kbIndex))).length, 0) / positive.reduce((sum, item) => sum + item.gold.size, 0);
  const mrr = positive.reduce((sum, item) => {
    const rank = item.result.ranked.findIndex((candidate) => item.gold.has(kbId(candidate.kbIndex)));
    return sum + (rank < 0 ? 0 : 1 / (rank + 1));
  }, 0) / positive.length;
  const selectedIds = (item) => new Set(item.result.selected.map((candidate) => kbId(candidate.kbIndex)));
  const correctAbstention = noCoverage.filter((item) => selectedIds(item).size === 0).length;
  const falseAbstention = positive.filter((item) => selectedIds(item).size === 0).length;
  const contextHit = (item) => [...selectedIds(item)].some((id) => item.gold.has(id));
  const contextRecallDenominator = positive.reduce((sum, item) => sum + item.gold.size, 0);
  const contextRecallNumerator = positive.reduce((sum, item) => sum + [...selectedIds(item)].filter((id) => item.gold.has(id)).length, 0);
  return {
    variant,
    n_total: outputs.length,
    n_covered_or_partial: positive.length,
    n_no_coverage: noCoverage.length,
    hit_at_1: Number(hit(1).toFixed(6)),
    hit_at_3: Number(hit(3).toFixed(6)),
    hit_at_5: Number(hit(5).toFixed(6)),
    recall_at_5: Number(recall(5).toFixed(6)),
    mrr: Number(mrr.toFixed(6)),
    correct_abstention_n: correctAbstention,
    correct_abstention_rate: Number((correctAbstention / noCoverage.length).toFixed(6)),
    false_abstention_n: falseAbstention,
    false_abstention_rate: Number((falseAbstention / positive.length).toFixed(6)),
    mean_selected_entries_all: Number((outputs.reduce((sum, item) => sum + item.result.selected.length, 0) / outputs.length).toFixed(6)),
    mean_best_score_all: Number((outputs.reduce((sum, item) => sum + item.result.bestScore, 0) / outputs.length).toFixed(6)),
    selected_context_hit_at_5: Number((positive.filter(contextHit).length / positive.length).toFixed(6)),
    selected_context_recall_at_5: Number((contextRecallNumerator / contextRecallDenominator).toFixed(6)),
    low_floor: options.lowFloor ?? 0.22,
    medium_threshold: options.mediumThreshold ?? 0.42,
    high_threshold: options.highThreshold ?? 0.70,
    sweep: options.sweep ?? "",
  };
};

const main = async () => {
  await fs.mkdir(OUT_DIR, { recursive: true });
  const goldText = await fs.readFile(GOLD_PATH, "utf8");
  const goldRows = parseCsv(goldText);
  if (goldRows.length !== 150) throw new Error(`Final gold inatteso: ${goldRows.length} righe`);
  const knowledgeBase = await compileKnowledge();
  const kbHash = sha256(JSON.stringify(knowledgeBase));
  const cases = goldRows.map((row) => ({ case_id: row.case_id, question_original: row.question_original, gold: parseIds(row.expert_relevant_kb_ids) }));
  const fullOptions = { useTokenSimilarity: true, useContainmentBonuses: true, useAcronymBonuses: true, useKeywordBonuses: true, useDefinitionBonuses: true };
  const variants = [
    ["full_production", fullOptions],
    ["base_phrase_overlap", { ...fullOptions, useContainmentBonuses: false, useAcronymBonuses: false, useKeywordBonuses: false, useDefinitionBonuses: false }],
    ["no_token_similarity", { ...fullOptions, useTokenSimilarity: false }],
    ["no_field_bonuses", { ...fullOptions, useAcronymBonuses: false, useKeywordBonuses: false, useDefinitionBonuses: false }],
  ];

  const ablationRows = [];
  const scorers = new Map();
  for (const [name, options] of variants) {
    const scorer = makeScorer(knowledgeBase, options);
    scorers.set(name, scorer);
    ablationRows.push(metricRow(name, cases, { scorer, lowFloor: 0.22, mediumThreshold: 0.42, highThreshold: 0.70 }));
  }

  const sensitivityRows = [];
  const floorSweep = [0.18, 0.22, 0.26, 0.30, 0.35];
  for (const lowFloor of floorSweep) {
    const scorer = makeScorer(knowledgeBase, { ...fullOptions, lowFloor, mediumThreshold: 0.42, highThreshold: 0.70 });
    sensitivityRows.push(metricRow(`floor_${lowFloor.toFixed(2)}`, cases, { scorer, lowFloor, mediumThreshold: 0.42, highThreshold: 0.70, sweep: "low_floor" }));
  }
  const threeThresholdPresets = [
    ["conservative", 0.26, 0.46, 0.75],
    ["production", 0.22, 0.42, 0.70],
    ["permissive", 0.18, 0.38, 0.65],
  ];
  for (const [name, lowFloor, mediumThreshold, highThreshold] of threeThresholdPresets) {
    const scorer = makeScorer(knowledgeBase, { ...fullOptions, lowFloor, mediumThreshold, highThreshold });
    sensitivityRows.push(metricRow(`preset_${name}`, cases, { scorer, lowFloor, mediumThreshold, highThreshold, sweep: "three_threshold_preset" }));
  }

  const ablationColumns = Object.keys(ablationRows[0]);
  const sensitivityColumns = Object.keys(sensitivityRows[0]);
  await writeCsv(path.join(OUT_DIR, "benchmark_150_retrieval_ablation.csv"), ablationColumns, ablationRows);
  await writeCsv(path.join(OUT_DIR, "benchmark_150_retrieval_threshold_sensitivity.csv"), sensitivityColumns, sensitivityRows);

  const full = ablationRows.find((row) => row.variant === "full_production");
  const report = {
    created_at: new Date().toISOString(),
    input: {
      final_gold_file: path.basename(GOLD_PATH),
      final_gold_sha256: sha256(goldText.replace(/^\ufeff/, "")),
      cases: cases.length,
      covered_or_partial: cases.filter((item) => item.gold.size > 0).length,
      no_coverage: cases.filter((item) => item.gold.size === 0).length,
      kb_entries: knowledgeBase.length,
      kb_version_sha256: kbHash,
    },
    protocol: {
      no_generation_calls: true,
      no_new_annotations: true,
      full_configuration: "Edufin/src/lib/confidence.ts reproduced with the frozen knowledge.ts snapshot",
      tie_breaking: "knowledge-base order for equal scores",
      metrics: "Hit@k and MRR on 116 covered/partial cases; multi-label Recall@5; threshold-aware context and abstention diagnostics on all 150 cases",
    },
    reproduction_check: {
      full_variant_matches_paper: {
        hit_at_5: full.hit_at_5 === 0.844828,
        mrr: full.mrr === 0.65208,
        correct_abstention_n: full.correct_abstention_n === 2,
      },
      full_metrics: full,
    },
    ablation: ablationRows,
    threshold_sensitivity: sensitivityRows,
    interpretation: [
      "Ablation rows are post-hoc diagnostics on the fixed final gold file, not a tuned development/test comparison.",
      "The production row retains the deployed ranking and confidence bands; the base row removes additive bonuses and the other rows remove one feature group.",
      "Threshold sensitivity changes which entries reach the prompt and whether the system abstains; the underlying score ranking is unchanged.",
      "The 150-question allocation is stratified and therefore is not a traffic prevalence estimate.",
    ],
  };
  await fs.writeFile(path.join(OUT_DIR, "benchmark_150_retrieval_ablation_report.json"), JSON.stringify(report, null, 2) + "\n", "utf8");

  const fmt = (value) => typeof value === "number" ? value.toFixed(3) : value;
  const md = [
    "# Retriever ablation and threshold sensitivity",
    "",
    "Post-hoc analysis on the adjudicated 150-question final gold. No LLM generation call or new annotation was used.",
    "",
    `- Final gold: ${report.input.covered_or_partial} covered/partial and ${report.input.no_coverage} no-coverage cases.`,
    `- KB: ${report.input.kb_entries} entries; SHA-256 ${report.input.kb_version_sha256}.`,
    "- Hit/Recall/MRR use the 116 covered/partial cases; abstention and context metrics use all 150 cases.",
    "",
    "## Ablation",
    "",
    "| Variant | Hit@1 | Hit@3 | Hit@5 | Recall@5 | MRR | Correct abstention | False abstention | Mean selected | Context Hit@5 |",
    "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ...ablationRows.map((row) => `| ${row.variant} | ${fmt(row.hit_at_1)} | ${fmt(row.hit_at_3)} | ${fmt(row.hit_at_5)} | ${fmt(row.recall_at_5)} | ${fmt(row.mrr)} | ${row.correct_abstention_n}/${row.n_no_coverage} (${fmt(row.correct_abstention_rate * 100)}%) | ${row.false_abstention_n}/${row.n_covered_or_partial} (${fmt(row.false_abstention_rate * 100)}%) | ${fmt(row.mean_selected_entries_all)} | ${fmt(row.selected_context_hit_at_5)} |`),
    "",
    "`full_production` reproduces the paper's final-gold Hit@5 (0.845), MRR (0.652), and correct abstention (2/34). `base_phrase_overlap` removes all additive bonuses. `no_token_similarity` removes the character-bigram Dice token match but retains phrase similarity and bonuses. `no_field_bonuses` removes acronym, keyword, and definition contributions while retaining term/query containment bonuses.",
    "",
    "## Sensitivity of the low confidence floor",
    "",
    "| Setting | Low floor | Medium | High | Context Hit@5 | Context Recall@5 | Correct abstention | False abstention | Mean selected |",
    "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ...sensitivityRows.filter((row) => row.sweep === "low_floor").map((row) => `| ${row.variant} | ${fmt(row.low_floor)} | ${fmt(row.medium_threshold)} | ${fmt(row.high_threshold)} | ${fmt(row.selected_context_hit_at_5)} | ${fmt(row.selected_context_recall_at_5)} | ${row.correct_abstention_n}/${row.n_no_coverage} (${fmt(row.correct_abstention_rate * 100)}%) | ${row.false_abstention_n}/${row.n_covered_or_partial} (${fmt(row.false_abstention_rate * 100)}%) | ${fmt(row.mean_selected_entries_all)} |`),
    "",
    "## Three-threshold presets",
    "",
    "| Preset | Low floor | Medium | High | Context Hit@5 | Context Recall@5 | Correct abstention | False abstention | Mean selected |",
    "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ...sensitivityRows.filter((row) => row.sweep === "three_threshold_preset").map((row) => `| ${row.variant} | ${fmt(row.low_floor)} | ${fmt(row.medium_threshold)} | ${fmt(row.high_threshold)} | ${fmt(row.selected_context_hit_at_5)} | ${fmt(row.selected_context_recall_at_5)} | ${row.correct_abstention_n}/${row.n_no_coverage} (${fmt(row.correct_abstention_rate * 100)}%) | ${row.false_abstention_n}/${row.n_covered_or_partial} (${fmt(row.false_abstention_rate * 100)}%) | ${fmt(row.mean_selected_entries_all)} |`),
    "",
    "## Interpretation",
    "",
    "The analysis is post-hoc and descriptive: the final gold file is reused for every variant, so no setting should be presented as tuned or selected for deployment. Ablations identify which feature groups affect the frozen-KB ranking. Threshold sweeps identify the coverage--abstention trade-off at the prompt boundary; they do not estimate production prevalence. The no-coverage stratum is deliberately enriched and must not be read as a traffic rate.",
    "",
  ].join("\n");
  await fs.writeFile(path.join(OUT_DIR, "benchmark_150_retrieval_ablation_report.md"), md, "utf8");
  console.log(JSON.stringify({ ablation: ablationRows, threshold_sensitivity: sensitivityRows }, null, 2));
};

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
