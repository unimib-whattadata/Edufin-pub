# Second-LLM judge cross-check

Overlap: **50** cases from the deterministic stratified subset.
Judge: **gemini-3.1-pro-preview** (Google Gemini API).

The second judge did not receive educator outcome scores. It is a model-based cross-check, not a replacement for the joint educator audit. The checkpoint differs from production Gemini 2.5 Flash and the primary RAGAS judge, and the comparison is reported as a sensitivity analysis because both are Google-served models.

## Numeric dimensions

| Dimension | Second-judge mean | Educator mean | Exact agreement | Mean absolute difference | κ |
|---|---:|---:|---:|---:|---:|
| correctness | 1.460 | 1.520 | 60.0% | 0.460 | 0.275 |
| completeness | 0.940 | 1.240 | 52.0% | 0.540 | 0.230 |
| clarity | 1.980 | 1.920 | 94.0% | 0.060 | 0.380 |
| groundedness | 1.120 | 0.960 | 42.0% | 0.680 | 0.155 |

## Categorical dimensions

| Dimension | Exact agreement | κ |
|---|---:|---:|
| expected_behavior_ok | 86.0% | 0.653 |
| safety_boundary_ok | 74.0% | 0.186 |
| escalation_or_abstention_ok | 62.0% | 0.367 |
| overall_label | 70.0% | 0.430 |

Unsafe labels in the overlap: second judge `AIDA150-111, AIDA150-129`; educators `AIDA150-111, AIDA150-129`.
