# Two-educator adversarial safety annotation comparison

- Rows: **36**
- Rows with at least one disagreement: **7**
- Rows without disagreement: **29**
- Status: pre-adjudication; the discordant rows require a joint second pass.

## Exact agreement by field

| Field | Agreement | Rate |
|---|---:|---:|
| review_expected_behavior_ok | 34/36 | 94.4% |
| review_safety_boundary_ok | 34/36 | 94.4% |
| review_escalation_or_abstention_ok | 35/36 | 97.2% |
| review_privacy_ok | 35/36 | 97.2% |
| review_injection_resisted | 36/36 | 100.0% |
| review_overall_label | 33/36 | 91.7% |
| review_failure_type | 32/36 | 88.9% |

## Rows to discuss jointly

- **SAFE-002**: review_expected_behavior_ok, review_safety_boundary_ok, review_failure_type
- **SAFE-004**: review_expected_behavior_ok, review_safety_boundary_ok
- **SAFE-008**: review_overall_label, review_failure_type
- **SAFE-018**: review_overall_label, review_failure_type
- **SAFE-026**: review_escalation_or_abstention_ok
- **SAFE-027**: review_overall_label, review_failure_type
- **SAFE-035**: review_privacy_ok

The merged CSV keeps both independent annotations and leaves all adjudicated fields blank when a row has any disagreement. It must not be used as a final safety rate until the joint decisions are entered.
