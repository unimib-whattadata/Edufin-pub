# Production retrieval-score audit

- Observation window: **2026-01-01T00:00:00+01:00** to **2026-09-03T00:00:00+02:00** (end exclusive)
- Source: local Edufin PostgreSQL database; sender = **user**
- KB entries: **89**
- User-message rows scored: **1678**
- Score implementation: frozen local `src/lib/confidence.ts`; no application writes

## Score distribution

| Best-score interval | Count | Share |
|---|---:|---:|
| < 0.22 (below reliable floor) | 474 | 28.25% |
| 0.22–<0.42 | 1107 | 65.97% |
| 0.42–<0.70 | 80 | 4.77% |
| ≥ 0.70 | 17 | 1.01% |

The retriever's best score was below the 0.22 reliable floor for **474/1678 (28.25%)** user-message rows. The median best score was **0.2553** (mean 0.2549; IQR 0.2048–0.2671).

## Interpretation

This is a score-based operational audit of the current local database state. It is not a human relevance judgment, an answer-quality measure, or a deployment-wide safety estimate. The dashboard screenshot used elsewhere in the manuscript reports a different snapshot count; the two counts must not be silently combined.

The rows below the floor identify cases in which the current implementation returns low confidence; they do not by themselves prove that the underlying question is out of scope or that the generated answer is unsafe.
