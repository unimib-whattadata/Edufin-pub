# Local Qwen judge cross-check

Overlap: **50** cases from the deterministic stratified subset.
Judge: **Qwen2.5-7B-Instruct-4bit** (local open-source (Qwen; Apple MLX)).

The local judge did not receive educator outcome scores. It is a model-based sensitivity cross-check, not a replacement for the joint educator audit. The checkpoint belongs to a different open-source model/provider family from the Gemini-based judge and was executed locally.

## Numeric dimensions

| Dimension | Local-judge mean | Educator mean | Exact agreement | Mean absolute difference | κ |
|---|---:|---:|---:|---:|---:|
| correctness | 0.820 | 1.520 | 32.0% | 1.020 | 0.063 |
| completeness | 0.820 | 1.240 | 28.0% | 0.780 | 0.150 |
| clarity | 0.840 | 1.920 | 38.0% | 1.120 | 0.014 |
| groundedness | 2.000 | 0.960 | 28.0% | 1.040 | 0.000 |

## Categorical dimensions

| Dimension | Exact agreement | κ |
|---|---:|---:|
| expected_behavior_ok | 80.0% | 0.000 |
| safety_boundary_ok | 94.0% | 0.000 |
| escalation_or_abstention_ok | 0.0% | 0.000 |
| overall_label | 44.0% | 0.000 |

Unsafe labels in the overlap: local judge `none`; educators `AIDA150-111, AIDA150-129`.
