#!/usr/bin/env node
/**
 * Read-only audit of the production database retrieval-score distribution.
 *
 * The script mirrors Edufin/src/lib/confidence.ts, but precomputes character
 * bigrams and word-to-feature matches so that long historical message rows can
 * be audited without changing the application or exporting message text.
 * Only aggregate JSON/Markdown output is written.
 */

import fs from "node:fs/promises";
import path from "node:path";
import { createRequire } from "node:module";
import ts from "/Users/Fabio_Dadda/Desktop/edufin-new/Edufin/node_modules/typescript/lib/typescript.js";

const ROOT = "/Users/Fabio_Dadda/Desktop/edufin-new/Edufin";
const OUT_DIR = path.resolve(path.dirname(new URL(import.meta.url).pathname));
const START = process.env.AUDIT_START ?? "2026-01-01T00:00:00+01:00";
const END = process.env.AUDIT_END ?? "2026-09-03T00:00:00+02:00";
const OUTPUT_JSON = path.join(OUT_DIR, "production_retrieval_audit_report.json");
const OUTPUT_MD = path.join(OUT_DIR, "production_retrieval_audit_report.md");

const STOP_WORDS = new Set([
  "a", "ad", "al", "allo", "ai", "agli", "all", "alla", "alle", "anche",
  "che", "chi", "con", "come", "cui", "da", "dal", "dallo", "dai", "dagli",
  "dalla", "dalle", "dei", "degli", "del", "della", "delle", "di", "dove",
  "e", "ed", "gli", "ha", "hai", "ho", "i", "il", "in", "io", "la", "le",
  "lo", "ma", "mi", "ne", "nel", "nella", "nelle", "nello", "non", "o", "per",
  "piu", "quale", "quali", "quando", "quanto", "se", "sei", "sia", "sono", "su",
  "tra", "un", "una", "uno", "voi",
]);

const normalizeText = (text) => String(text ?? "")
  .toLowerCase()
  .normalize("NFD")
  .replace(/[\u0300-\u036f]/g, "")
  .replace(/[’']/g, " ")
  .replace(/[^a-z0-9\s]/g, " ")
  .replace(/\s+/g, " ")
  .trim();

const getSignificantWords = (text) => {
  const normalized = normalizeText(text);
  if (!normalized) return [];
  return [...new Set(normalized.split(" ").filter(
    (word) => word.length >= 3 && !STOP_WORDS.has(word),
  ))];
};

const makeBigrams = (text) => {
  const compact = text.replace(/\s+/g, "");
  const counts = new Map();
  for (let i = 0; i < compact.length - 1; i += 1) {
    const bigram = compact.slice(i, i + 2);
    counts.set(bigram, (counts.get(bigram) ?? 0) + 1);
  }
  return { compact, counts };
};

const queryBigramCache = new Map();
const getQueryBigrams = (text) => {
  let value = queryBigramCache.get(text);
  if (!value) {
    value = makeBigrams(text);
    queryBigramCache.set(text, value);
  }
  return value;
};

// Equivalent to string-similarity's compareTwoStrings(first, second), with
// the first-string bigram map supplied/cached and the second map precomputed.
const comparePrepared = (first, secondPrepared) => {
  if (first.replace(/\s+/g, "") === secondPrepared.compact) return 1;
  const firstPrepared = getQueryBigrams(first);
  if (firstPrepared.compact.length < 2 || secondPrepared.compact.length < 2) return 0;
  const remaining = new Map(firstPrepared.counts);
  let intersection = 0;
  for (let i = 0; i < secondPrepared.compact.length - 1; i += 1) {
    const bigram = secondPrepared.compact.slice(i, i + 2);
    const count = remaining.get(bigram) ?? 0;
    if (count > 0) {
      remaining.set(bigram, count - 1);
      intersection += 1;
    }
  }
  return (2 * intersection) /
    (firstPrepared.compact.length + secondPrepared.compact.length - 2);
};

const makeFeature = (value) => {
  const normalized = normalizeText(value);
  return {
    text: normalized,
    words: getSignificantWords(value),
    bigrams: makeBigrams(normalized),
  };
};

const compileKnowledgeBase = async () => {
  const source = await fs.readFile(path.join(ROOT, "src/lib/knowledge.ts"), "utf8");
  const compiled = ts.transpileModule(source, {
    compilerOptions: {
      target: ts.ScriptTarget.ES2022,
      module: ts.ModuleKind.ESNext,
    },
    fileName: "knowledge.ts",
  }).outputText;
  const module = await import(`data:text/javascript;base64,${Buffer.from(compiled).toString("base64")}`);
  return module.knowledgeBase;
};

const buildScorer = (knowledgeBase) => {
  const prepared = knowledgeBase.map((item) => {
    const keywords = item.keywords ?? [];
    return {
      item,
      term: makeFeature(item.term),
      acronym: item.acronym ? makeFeature(item.acronym) : null,
      keywords: keywords.map((keyword) => makeFeature(keyword)),
      keywordsAll: makeFeature(keywords.join(" ")),
      definition: makeFeature(item.definition),
    };
  });

  const features = [];
  for (const row of prepared) {
    for (const feature of [row.term, row.acronym, row.keywordsAll, row.definition]) {
      if (feature) feature.id = features.push(feature) - 1;
    }
  }

  // Each unique target token stores the feature IDs in which it occurs. This
  // lets coverage and balanced overlap be computed without rescanning every
  // definition for every query word.
  const targetTokens = new Map();
  for (const feature of features) {
    for (const word of feature.words) {
      let token = targetTokens.get(word);
      if (!token) {
        token = { word, bigrams: makeBigrams(word), featureIds: new Set() };
        targetTokens.set(word, token);
      }
      token.featureIds.add(feature.id);
    }
  }
  const targetTokenList = [...targetTokens.values()];
  const inputWordFeatureCache = new Map();

  const matchedFeatureIds = (inputWord) => {
    let cached = inputWordFeatureCache.get(inputWord);
    if (cached) return cached;
    const matches = new Set();
    for (const token of targetTokenList) {
      const matchesWord = inputWord === token.word ||
        (inputWord.length >= 4 && token.word.length >= 4 &&
          (token.word.includes(inputWord) || inputWord.includes(token.word))) ||
        comparePrepared(inputWord, token.bigrams) >= 0.75;
      if (matchesWord) {
        for (const featureId of token.featureIds) matches.add(featureId);
      }
    }
    cached = [...matches];
    inputWordFeatureCache.set(inputWord, cached);
    return cached;
  };

  const score = (input) => {
    const normalizedInput = normalizeText(input);
    const inputWords = getSignificantWords(input);
    const featureCounts = new Int32Array(features.length);
    for (const word of inputWords) {
      for (const featureId of matchedFeatureIds(word)) featureCounts[featureId] += 1;
    }

    const coverage = (feature) => {
      if (!inputWords.length || !feature.words.length) return 0;
      return featureCounts[feature.id] / inputWords.length;
    };
    const balanced = (feature) => {
      if (!inputWords.length || !feature.words.length) return 0;
      const matched = featureCounts[feature.id];
      if (!matched) return 0;
      const precision = matched / inputWords.length;
      const recall = matched / feature.words.length;
      return (2 * precision * recall) / (precision + recall);
    };

    let bestScore = -1;
    let bestTerm = "";
    for (const row of prepared) {
      let scoreValue = comparePrepared(normalizedInput, row.term.bigrams) * 0.55 +
        balanced(row.term) * 0.45;
      if (normalizedInput.includes(row.term.text)) scoreValue += 0.25;
      if (normalizedInput.length >= 6 && row.term.text.includes(normalizedInput)) scoreValue += 0.1;

      if (row.acronym) {
        scoreValue = Math.max(
          scoreValue,
          comparePrepared(normalizedInput, row.acronym.bigrams) * 0.55 +
            balanced(row.acronym) * 0.45,
        );
        if (normalizedInput.includes(row.acronym.text) || inputWords.includes(row.acronym.text)) {
          scoreValue += 0.25;
        }
      }

      if (row.keywords.length) {
        const keywordPhraseScore = Math.max(
          ...row.keywords.map((keyword) => comparePrepared(normalizedInput, keyword.bigrams)),
        );
        scoreValue += coverage(row.keywordsAll) * 0.35 + keywordPhraseScore * 0.15;
        if (row.keywords.some((keyword) => normalizedInput.includes(keyword.text))) scoreValue += 0.15;
      }

      scoreValue += coverage(row.definition) * 0.18;
      if (normalizedInput.length >= 8 && row.definition.text.includes(normalizedInput)) scoreValue += 0.2;
      scoreValue = Math.min(scoreValue, 1);
      if (scoreValue > bestScore) {
        bestScore = scoreValue;
        bestTerm = row.item.term;
      }
    }

    return { score: bestScore, term: bestTerm };
  };

  return { score, cache: inputWordFeatureCache, featureCount: features.length };
};

const loadDatabaseUrl = async () => {
  const envText = await fs.readFile(path.join(ROOT, ".env"), "utf8");
  const line = envText.split(/\r?\n/).find((entry) => entry.startsWith("DATABASE_URL="));
  if (!line) throw new Error("DATABASE_URL missing from local Edufin .env");
  return line.slice("DATABASE_URL=".length).trim().replace(/^['"]|['"]$/g, "");
};

const writeReports = async (report) => {
  await fs.writeFile(OUTPUT_JSON, `${JSON.stringify(report, null, 2)}\n`, "utf8");
  const pct = (value) => `${(value * 100).toFixed(2)}%`;
  const lines = [
    "# Production retrieval-score audit",
    "",
    `- Observation window: **${report.window.start}** to **${report.window.end_exclusive}** (end exclusive)`,
    `- Source: local Edufin PostgreSQL database; sender = **user**`,
    `- KB entries: **${report.kb_entries}**`,
    `- User-message rows scored: **${report.query_count}**`,
    `- Score implementation: frozen local ` + "`src/lib/confidence.ts`" + `; no application writes`,
    "",
    "## Score distribution",
    "",
    "| Best-score interval | Count | Share |",
    "|---|---:|---:|",
    `| < 0.22 (below reliable floor) | ${report.bins.below_0_22} | ${pct(report.bins.below_0_22 / report.query_count)} |`,
    `| 0.22–<0.42 | ${report.bins.from_0_22_to_0_42} | ${pct(report.bins.from_0_22_to_0_42 / report.query_count)} |`,
    `| 0.42–<0.70 | ${report.bins.from_0_42_to_0_70} | ${pct(report.bins.from_0_42_to_0_70 / report.query_count)} |`,
    `| ≥ 0.70 | ${report.bins.at_least_0_70} | ${pct(report.bins.at_least_0_70 / report.query_count)} |`,
    "",
    `The retriever's best score was below the 0.22 reliable floor for **${report.bins.below_0_22}/${report.query_count} (${pct(report.bins.below_0_22 / report.query_count)})** user-message rows. The median best score was **${report.score_summary.median.toFixed(4)}** (mean ${report.score_summary.mean.toFixed(4)}; IQR ${report.score_summary.q25.toFixed(4)}–${report.score_summary.q75.toFixed(4)}).`,
    "",
    "## Interpretation",
    "",
    "This is a score-based operational audit of the current local database state. It is not a human relevance judgment, an answer-quality measure, or a deployment-wide safety estimate. The dashboard screenshot used elsewhere in the manuscript reports a different snapshot count; the two counts must not be silently combined.",
    "",
    "The rows below the floor identify cases in which the current implementation returns low confidence; they do not by themselves prove that the underlying question is out of scope or that the generated answer is unsafe.",
  ];
  await fs.writeFile(OUTPUT_MD, `${lines.join("\n")}\n`, "utf8");
};

const main = async () => {
  const knowledgeBase = await compileKnowledgeBase();
  const scorer = buildScorer(knowledgeBase);
  const require = createRequire(import.meta.url);
  const postgres = require(path.join(ROOT, "node_modules/postgres"));
  const databaseUrl = await loadDatabaseUrl();
  const sql = postgres(databaseUrl, { max: 1, connect_timeout: 15, idle_timeout: 10 });
  try {
    const rows = await sql`
      select message_id, time, text
      from "edufin-db_message"
      where sender = 'user'
        and time >= ${START}::timestamptz
        and time < ${END}::timestamptz
      order by time, message_id
    `;
    const bins = {
      below_0_22: 0,
      from_0_22_to_0_42: 0,
      from_0_42_to_0_70: 0,
      at_least_0_70: 0,
    };
    const confidenceCounts = { low: 0, medium: 0, high: 0 };
    const termCounts = new Map();
    const scores = [];
    const lengthStats = [];
    const t0 = Date.now();
    for (const [index, row] of rows.entries()) {
      const result = scorer.score(row.text);
      scores.push(result.score);
      lengthStats.push(row.text.length);
      if (result.score < 0.22) {
        bins.below_0_22 += 1;
        confidenceCounts.low += 1;
      } else if (result.score < 0.42) {
        bins.from_0_22_to_0_42 += 1;
        confidenceCounts.low += 1;
      } else if (result.score < 0.70) {
        bins.from_0_42_to_0_70 += 1;
        confidenceCounts.medium += 1;
      } else {
        bins.at_least_0_70 += 1;
        confidenceCounts.high += 1;
      }
      termCounts.set(result.term, (termCounts.get(result.term) ?? 0) + 1);
      if ((index + 1) % 100 === 0) process.stderr.write(`scored ${index + 1}/${rows.length}\n`);
    }
    scores.sort((a, b) => a - b);
    lengthStats.sort((a, b) => a - b);
    const quantile = (p) => scores[Math.floor((scores.length - 1) * p)] ?? 0;
    const mean = scores.length ? scores.reduce((sum, value) => sum + value, 0) / scores.length : 0;
    const lengthQuantile = (p) => lengthStats[Math.floor((lengthStats.length - 1) * p)] ?? 0;
    const report = {
      report_type: "production_retrieval_score_audit",
      generated_at: new Date().toISOString(),
      window: { start: START, end_exclusive: END },
      source: "local Edufin PostgreSQL database; read-only query; sender=user",
      kb_entries: knowledgeBase.length,
      query_count: rows.length,
      bins,
      below_0_22_count: bins.below_0_22,
      below_0_22_rate: rows.length ? bins.below_0_22 / rows.length : 0,
      confidence_counts: confidenceCounts,
      score_summary: {
        min: scores[0] ?? 0,
        q25: quantile(0.25),
        median: quantile(0.5),
        q75: quantile(0.75),
        max: scores.at(-1) ?? 0,
        mean,
      },
      message_length_summary: {
        min: lengthStats[0] ?? 0,
        median: lengthQuantile(0.5),
        p90: lengthQuantile(0.9),
        max: lengthStats.at(-1) ?? 0,
      },
      top_best_match_terms: [...termCounts.entries()]
        .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
        .slice(0, 15)
        .map(([term, count]) => ({ term, count })),
      implementation: {
        source_file: "Edufin/src/lib/confidence.ts",
        thresholds: { reliable_floor: 0.22, medium: 0.42, high: 0.70 },
        writes_to_database: false,
        scorer_feature_cache_entries: scorer.cache.size,
        scorer_feature_count: scorer.featureCount,
        elapsed_seconds: Number(((Date.now() - t0) / 1000).toFixed(3)),
      },
      interpretation: "Score-based operational audit only; not a human relevance label, answer-quality measure, safety rate, or prevalence estimate. Dashboard screenshot counts are a different snapshot and must not be silently combined.",
    };
    await writeReports(report);
    process.stderr.write(`wrote ${OUTPUT_JSON}\nwrote ${OUTPUT_MD}\n`);
  } finally {
    await sql.end({ timeout: 5 });
  }
};

main().catch((error) => {
  process.stderr.write(`${error?.stack ?? error}\n`);
  process.exitCode = 1;
});
