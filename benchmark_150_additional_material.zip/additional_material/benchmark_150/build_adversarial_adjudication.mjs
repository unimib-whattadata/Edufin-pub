import fs from "node:fs/promises";
import crypto from "node:crypto";
import { Workbook } from "@oai/artifact-tool";

const defaultA = "/Users/Fabio_Dadda/Downloads/adversarial_safety_annotation_EDU-A_completed.csv";
const defaultB = "/Users/Fabio_Dadda/Downloads/adversarial_safety_annotation_EDU-B_completed.csv";
const outputPath = "benchmark_150/adversarial_safety_annotations_merged_for_adjudication.csv";
const reportPath = "benchmark_150/adversarial_safety_annotations_two_expert_report.json";
const markdownPath = "benchmark_150/adversarial_safety_annotations_two_expert_report.md";

const reviewFields = [
  "review_expected_behavior_ok",
  "review_safety_boundary_ok",
  "review_escalation_or_abstention_ok",
  "review_privacy_ok",
  "review_injection_resisted",
  "review_overall_label",
  "review_failure_type",
];
const baseFields = [
  "probe_id", "category", "attack_family", "question", "expected_behavior",
  "expected_safety_boundary", "expected_escalation_or_abstention", "expected_risk",
  "success_criterion", "aida_answer", "aida_status", "aida_retrieved_context",
  "aida_retrieved_entry_count",
];
const adjudicatedFields = reviewFields.map((field) => field.replace(/^review_/, "adjudicated_"));
const outputFields = [
  ...baseFields,
  ...reviewFields.map((field) => `edu_a_${field}`),
  ...reviewFields.map((field) => `edu_b_${field}`),
  "edu_a_notes", "edu_b_notes", "disagreement_fields", "needs_adjudication",
  ...adjudicatedFields, "adjudicated_notes", "adjudicator_id", "adjudication_status",
];

function csvEscape(value) {
  const text = value === null || value === undefined ? "" : String(value);
  return /[",\n\r]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
}

async function readCsvViaArtifact(path) {
  const csv = await fs.readFile(path, "utf8");
  const workbook = await Workbook.fromCSV(csv, { sheetName: "Data" });
  const values = workbook.worksheets.getItem("Data").getUsedRange().values;
  const headers = values[0].map((value, index) => (index === 0 ? String(value).replace(/^\ufeff/, "") : String(value)));
  return {
    headers,
    rows: values.slice(1).map((row) => Object.fromEntries(headers.map((header, index) => [header, row[index] ?? ""]))),
  };
}

async function main() {
  const [a, b] = await Promise.all([readCsvViaArtifact(defaultA), readCsvViaArtifact(defaultB)]);
  if (a.rows.length !== b.rows.length) throw new Error(`Row-count mismatch: ${a.rows.length} vs ${b.rows.length}`);
  const merged = [];
  const fieldCounts = Object.fromEntries(reviewFields.map((field) => [field, { agreed: 0, disagreed: 0 }]));
  const disagreementRows = [];
  for (let index = 0; index < a.rows.length; index += 1) {
    const left = a.rows[index];
    const right = b.rows[index];
    if (left.probe_id !== right.probe_id) throw new Error(`Probe order mismatch at row ${index + 2}`);
    const disagreementFields = reviewFields.filter((field) => left[field] !== right[field]);
    for (const field of reviewFields) {
      fieldCounts[field][left[field] === right[field] ? "agreed" : "disagreed"] += 1;
    }
    const row = Object.fromEntries(baseFields.map((field) => [field, left[field] ?? ""]));
    for (const field of reviewFields) row[`edu_a_${field}`] = left[field] ?? "";
    for (const field of reviewFields) row[`edu_b_${field}`] = right[field] ?? "";
    row.edu_a_notes = left.review_notes ?? "";
    row.edu_b_notes = right.review_notes ?? "";
    row.disagreement_fields = disagreementFields.join(";");
    row.needs_adjudication = disagreementFields.length ? "yes" : "no";
    for (const field of adjudicatedFields) {
      const sourceField = field.replace(/^adjudicated_/, "review_");
      row[field] = disagreementFields.length ? "" : (left[sourceField] ?? "");
    }
    row.adjudicated_notes = "";
    row.adjudicator_id = "";
    row.adjudication_status = disagreementFields.length ? "pending_joint_adjudication" : "agreement_pending_joint_confirmation";
    merged.push(row);
    if (disagreementFields.length) disagreementRows.push({
      probe_id: left.probe_id,
      fields: disagreementFields,
      educator_a: Object.fromEntries(disagreementFields.map((field) => [field, left[field] ?? ""])),
      educator_b: Object.fromEntries(disagreementFields.map((field) => [field, right[field] ?? ""])),
    });
  }

  // Author the merged matrix through artifact-tool, then serialize the same
  // values as a CSV for the educator adjudication workflow.
  const workbook = Workbook.create();
  const sheet = workbook.worksheets.add("Adjudication");
  const matrix = [outputFields, ...merged.map((row) => outputFields.map((field) => row[field] ?? ""))];
  sheet.getRangeByIndexes(0, 0, matrix.length, outputFields.length).values = matrix;
  sheet.freezePanes.freezeRows(1);
  const check = await workbook.inspect({ kind: "table", range: `Adjudication!A1:K${Math.min(matrix.length, 6)}`, include: "values", tableMaxRows: 6, tableMaxCols: 11, tableMaxCellChars: 90 });
  console.log(check.ndjson);
  const csvText = matrix.map((row) => row.map(csvEscape).join(",")).join("\n") + "\n";
  await fs.writeFile(outputPath, `\ufeff${csvText}`, "utf8");

  const hash = (path) => crypto.createHash("sha256").update(path).digest("hex");
  const report = {
    source_files: {
      educator_a: defaultA,
      educator_b: defaultB,
      educator_a_sha256: hash(await fs.readFile(defaultA)),
      educator_b_sha256: hash(await fs.readFile(defaultB)),
    },
    rows: merged.length,
    evaluation_fields: reviewFields,
    field_agreement: Object.fromEntries(reviewFields.map((field) => [field, {
      agreed: fieldCounts[field].agreed,
      disagreed: fieldCounts[field].disagreed,
      agreement_rate: fieldCounts[field].agreed / merged.length,
    }])),
    rows_with_any_disagreement: disagreementRows.length,
    rows_without_disagreement: merged.length - disagreementRows.length,
    disagreement_rows: disagreementRows,
    overall_label_counts: {
      educator_a: Object.fromEntries([...new Set(a.rows.map((row) => row.review_overall_label))].map((label) => [label, a.rows.filter((row) => row.review_overall_label === label).length])),
      educator_b: Object.fromEntries([...new Set(b.rows.map((row) => row.review_overall_label))].map((label) => [label, b.rows.filter((row) => row.review_overall_label === label).length])),
    },
    interpretation: "Pre-adjudication comparison only. The seven discordant rows require a joint second pass; no adjudicated safety rate is reported here.",
  };
  await fs.writeFile(reportPath, `${JSON.stringify(report, null, 2)}\n`, "utf8");
  const lines = [
    "# Two-educator adversarial safety annotation comparison",
    "",
    `- Rows: **${report.rows}**` ,
    `- Rows with at least one disagreement: **${report.rows_with_any_disagreement}**`,
    `- Rows without disagreement: **${report.rows_without_disagreement}**`,
    "- Status: pre-adjudication; the discordant rows require a joint second pass.",
    "",
    "## Exact agreement by field",
    "",
    "| Field | Agreement | Rate |",
    "|---|---:|---:|",
    ...reviewFields.map((field) => `| ${field} | ${report.field_agreement[field].agreed}/${report.rows} | ${(100 * report.field_agreement[field].agreement_rate).toFixed(1)}% |`),
    "",
    "## Rows to discuss jointly",
    "",
    ...disagreementRows.map((item) => `- **${item.probe_id}**: ${item.fields.join(", ")}`),
    "",
    "The merged CSV keeps both independent annotations and leaves all adjudicated fields blank when a row has any disagreement. It must not be used as a final safety rate until the joint decisions are entered.",
  ];
  await fs.writeFile(markdownPath, `${lines.join("\n")}\n`, "utf8");
  console.log(JSON.stringify({ outputPath, reportPath, markdownPath, rows: report.rows, rows_with_any_disagreement: report.rows_with_any_disagreement }, null, 2));
}

main().catch((error) => { console.error(error); process.exitCode = 1; });
