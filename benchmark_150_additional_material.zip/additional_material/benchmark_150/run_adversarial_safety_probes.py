#!/usr/bin/env python3
"""Execute synthetic adversarial safety probes against the local Edufin flow."""

from __future__ import annotations

import argparse
import csv
import json
import re
from pathlib import Path
from typing import Any

import httpx

import run_aida_answers as aida


OUTPUT_FIELDS = [
    "probe_id", "category", "attack_family", "question", "expected_behavior",
    "expected_safety_boundary", "expected_escalation_or_abstention", "expected_risk",
    "success_criterion", "source_note", "aida_answer", "aida_status", "aida_error",
    "aida_run_id", "aida_attempt", "aida_started_at", "aida_completed_at", "aida_latency_ms",
    "aida_chat_id", "aida_message_id", "aida_retrieved_context", "aida_retrieved_context_sha256",
    "aida_knowledge_context_chars", "aida_retrieved_entry_count",
]


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text("".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows), encoding="utf-8")
    temporary.replace(path)


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8", newline="") as handle:
        handle.write("\ufeff")
        writer = csv.DictWriter(handle, fieldnames=OUTPUT_FIELDS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows({field: row.get(field, "") for field in OUTPUT_FIELDS} for row in rows)
    temporary.replace(path)


def count_retrieved_entries(context: str) -> int:
    return len(re.findall(r"(?:^|\n)Termine:\s*", context))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=Path("adversarial_safety_probes.csv"))
    parser.add_argument("--output", type=Path, default=Path("adversarial_safety_probes_answers.csv"))
    parser.add_argument("--checkpoint", type=Path, default=Path("adversarial_safety_probes_answers.jsonl"))
    parser.add_argument("--base-url", default="http://127.0.0.1:3000")
    parser.add_argument("--run-id", default="aida-adversarial-safety-20260903")
    parser.add_argument("--max-attempts", type=int, default=3)
    parser.add_argument("--timeout", type=float, default=240.0)
    args = parser.parse_args()

    probes = read_csv(args.input)
    checkpoint = read_jsonl(args.checkpoint)
    completed = {row.get("probe_id"): row for row in checkpoint if row.get("aida_status") == "ok"}
    all_rows: list[dict[str, Any]] = []

    with httpx.Client(headers={"Content-Type": "application/json"}, timeout=args.timeout) as client:
        for index, probe in enumerate(probes, start=1):
            probe_id = probe["probe_id"]
            if probe_id in completed:
                answer = completed[probe_id]
            else:
                answer = aida.run_one(
                    client,
                    args.base_url.rstrip("/"),
                    probe["question"],
                    run_id=args.run_id,
                    case_id=probe_id,
                    max_attempts=args.max_attempts,
                    timeout_seconds=args.timeout,
                )
                checkpoint = [row for row in checkpoint if row.get("probe_id") != probe_id]
                checkpoint.append({"probe_id": probe_id, **answer})
                write_jsonl(args.checkpoint, checkpoint)

            row = dict(probe)
            row.update(answer)
            context = str(row.get("aida_retrieved_context") or "")
            row["aida_retrieved_entry_count"] = count_retrieved_entries(context)
            all_rows.append(row)
            write_csv(args.output, all_rows)
            print(f"[{index}/{len(probes)}] {probe_id}: {row.get('aida_status')}", flush=True)

    ok = sum(row.get("aida_status") == "ok" for row in all_rows)
    print(json.dumps({"run_id": args.run_id, "rows": len(all_rows), "ok": ok, "errors": len(all_rows) - ok, "output": str(args.output), "checkpoint": str(args.checkpoint)}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
