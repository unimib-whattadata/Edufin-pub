#!/usr/bin/env python3
"""Validate and summarize the jointly adjudicated AIDA answer evaluation."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import random
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path
from typing import Any


NUMERIC_FIELDS = [
    "eval_correctness_0_2",
    "eval_completeness_0_2",
    "eval_clarity_0_2",
    "eval_groundedness_0_2",
]
BOOLEAN_FIELDS = [
    "eval_expected_behavior_ok",
    "eval_safety_boundary_ok",
    "eval_escalation_or_abstention_ok",
]


def load(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def bootstrap_ci(values: list[float], *, seed: int = 20260903, samples: int = 10_000) -> list[float]:
    rng = random.Random(seed)
    n = len(values)
    estimates = []
    for _ in range(samples):
        total = sum(values[rng.randrange(n)] for _ in range(n))
        estimates.append(total / n)
    estimates.sort()
    return [round(estimates[int(samples * 0.025)], 4), round(estimates[int(samples * 0.975) - 1], 4)]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--answer-run", type=Path)
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--output-md", type=Path, required=True)
    args = parser.parse_args()

    rows = load(args.input)
    if len(rows) != 150 or len({row.get("case_id") for row in rows}) != 150:
        raise SystemExit("Il file finale deve contenere 150 case_id unici")
    if any(row.get("evaluation_status") != "done" for row in rows):
        raise SystemExit("Tutte le righe devono avere evaluation_status=done")
    if not all(row.get("aida_status") == "ok" and row.get("aida_answer", "").strip() for row in rows):
        raise SystemExit("Sono presenti risposte AIDA mancanti o non riuscite")
    if args.answer_run:
        run_rows = {row["case_id"]: row for row in load(args.answer_run)}
        if set(run_rows) != {row["case_id"] for row in rows}:
            raise SystemExit("Il final file non coincide con il run AIDA")
        for row in rows:
            base = run_rows[row["case_id"]]
            if row["aida_answer"] != base["aida_answer"] or row["aida_retrieved_context_sha256"] != base["aida_retrieved_context_sha256"]:
                raise SystemExit(f"Risposta o contesto diverso nel caso {row['case_id']}")

    report: dict[str, Any] = {
        "created_at": datetime.now(UTC).isoformat(),
        "source_file_sha256": hashlib.sha256(args.input.read_bytes()).hexdigest(),
        "cases": len(rows),
        "evaluator_ids": sorted({row.get("evaluator_id", "") for row in rows}),
        "evaluation_status": dict(Counter(row.get("evaluation_status", "") for row in rows)),
        "numeric_fields": {},
        "boolean_fields": {},
        "overall_label": dict(Counter(row["eval_overall_label"] for row in rows)),
        "unsafe_case_ids": [row["case_id"] for row in rows if row["eval_overall_label"] == "unsafe"],
        "empty_notes": sum(not row.get("eval_notes", "").strip() for row in rows),
        "empty_error_or_omission": sum(not row.get("eval_error_or_omission", "").strip() for row in rows),
    }
    for field in NUMERIC_FIELDS:
        values = [int(row[field]) for row in rows]
        report["numeric_fields"][field] = {
            "distribution": dict(Counter(str(value) for value in values)),
            "mean": round(sum(values) / len(values), 4),
            "share_score_2": round(sum(value == 2 for value in values) / len(values), 4),
            "share_score_at_least_1": round(sum(value >= 1 for value in values) / len(values), 4),
            "bootstrap_95_ci_mean": bootstrap_ci([float(value) for value in values]),
        }
    for field in BOOLEAN_FIELDS:
        values = [1.0 if row[field] == "true" else 0.0 for row in rows]
        report["boolean_fields"][field] = {
            "distribution": dict(Counter(row[field] for row in rows)),
            "share_true": round(sum(values) / len(values), 4),
            "bootstrap_95_ci_share_true": bootstrap_ci(values),
        }
    for label in ("acceptable", "needs_revision", "unsafe"):
        values = [1.0 if row["eval_overall_label"] == label else 0.0 for row in rows]
        report.setdefault("overall_label_bootstrap_95_ci", {})[label] = bootstrap_ci(values)

    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    labels = report["overall_label"]
    lines = [
        "# Final joint answer-evaluation report",
        "",
        "This report uses the jointly adjudicated evaluation supplied by the two financial educators. It is the final answer-quality annotation for the 150-question AIDA run; the two individual files remain the independent pre-adjudication records.",
        "",
        "## Validation",
        "",
        f"- Cases: **{report['cases']}/150**, all case IDs unique.",
        f"- Evaluator identifier: **{', '.join(report['evaluator_ids'])}**.",
        f"- Evaluation status: **{report['evaluation_status']}**.",
        "- All AIDA answers and retrieval-context hashes match the original answer run.",
        "",
        "## Quality dimensions",
        "",
        "| Dimension | Mean / share | Bootstrap 95% interval |",
        "|---|---:|---:|",
    ]
    for field in NUMERIC_FIELDS:
        item = report["numeric_fields"][field]
        lines.append(f"| `{field}` mean | {item['mean']:.3f} / 2 | [{item['bootstrap_95_ci_mean'][0]:.3f}, {item['bootstrap_95_ci_mean'][1]:.3f}] |")
    for field in BOOLEAN_FIELDS:
        item = report["boolean_fields"][field]
        lines.append(f"| `{field}` true | {100 * item['share_true']:.1f}% | [{100 * item['bootstrap_95_ci_share_true'][0]:.1f}%, {100 * item['bootstrap_95_ci_share_true'][1]:.1f}%] |")
    lines.extend(
        [
            "",
            "## Overall judgement",
            "",
            f"- `acceptable`: **{labels.get('acceptable', 0)}/150 ({100 * labels.get('acceptable', 0) / 150:.1f}%)**.",
            f"- `needs_revision`: **{labels.get('needs_revision', 0)}/150 ({100 * labels.get('needs_revision', 0) / 150:.1f}%)**.",
            f"- `unsafe`: **{labels.get('unsafe', 0)}/150 ({100 * labels.get('unsafe', 0) / 150:.1f}%)**; cases: {', '.join(report['unsafe_case_ids'])}.",
            "",
            "These are human evaluation results, not retrieval metrics. They should be reported together with the annotation protocol, the two independent pre-adjudication files, and the joint second-pass procedure.",
            "",
        ]
    )
    args.output_md.parent.mkdir(parents=True, exist_ok=True)
    args.output_md.write_text("\n".join(lines), encoding="utf-8")
    print(json.dumps({"cases": 150, "overall_label": labels, "unsafe_case_ids": report["unsafe_case_ids"], "output_json": str(args.output_json), "output_md": str(args.output_md)}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
