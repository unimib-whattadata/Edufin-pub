# AIDA - confronto delle due annotazioni esperte

## Allineamento

- 150 casi comuni tra i due annotatori e il run automatico.
- 150/150 domande coincidono esattamente.
- Tutti gli ID KB sono validi rispetto al catalogo congelato.
- 106 casi concordano su tutti i campi chiave; 44 richiedono adjudication.

## Accordo tra annotatori

| Campo | Accordo esatto | Cohen's kappa |
|---|---:|---:|
| Copertura KB | 88.7% | 0.736 |
| Comportamento atteso | 84.7% | 0.760 |
| Categoria sicurezza | 92.7% | 0.886 |
| Severità | 83.3% | 0.753 |
| Set di ID KB | 91.3% | - |

L'accordo medio Jaccard tra i set di ID KB è 0.920. Le discrepanze non vengono risolte automaticamente: il file `benchmark_150_merged_for_adjudication.csv` mostra intersezione, unione e stato di adjudication per ogni caso.

## Retrieval: annotatore 1

Calcolato sui 127 casi con almeno una voce KB pertinente; i 23 casi `coverage=no` sono trattati separatamente come casi di astensione.

- Hit@1: 50.4%
- Hit@3: 76.4%
- Hit@5: 83.5%
- MRR: 0.643
- Recall@5 multi-label: 43.7%
- Astensione corretta sui casi senza copertura: 2/23 = 8.7%

## Retrieval: annotatore 2

Calcolato sui 116 casi con almeno una voce KB pertinente; i 34 casi `coverage=no` sono trattati separatamente.

- Hit@1: 50.9%
- Hit@3: 77.6%
- Hit@5: 84.5%
- MRR: 0.652
- Recall@5 multi-label: 43.2%
- Astensione corretta sui casi senza copertura: 2/34 = 5.9%

## Interpretazione

I risultati dei due annotatori sono molto simili. Il retriever porta una voce ritenuta pertinente nel top-5 in circa l'84% dei casi coperti o parzialmente coperti, ma il top-1 è corretto solo in circa metà dei casi. Il punto debole più evidente è l'over-retrieval: la soglia 0.22 lascia passare la maggior parte delle domande che gli esperti giudicano non coperte dalla KB.

Questi valori sono pronti per una valutazione preliminare. Prima della versione finale per l'articolo occorre adjudicare i 44 casi discordanti e fissare la definizione multi-label delle metriche.
