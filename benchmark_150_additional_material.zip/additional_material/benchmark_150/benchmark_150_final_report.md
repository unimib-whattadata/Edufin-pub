# Final gold report: AIDA 150-question retrieval audit

The aggregated file produced in a joint second pass by the same two financial
educators resolves the 44 initially discordant cases. All 150 rows have
`annotation_status=done` and the aggregate identifier is `ADJ-CX01`. The
resulting labels are used as the final gold set below.

The questions were sampled from a separate pre-deployment educator study and
are not a sample of deployment traffic. The production-dashboard snapshot is
reported separately in the manuscript.

## Final coverage

| Label | Cases |
|---|---:|
| `yes` | 11 |
| `partial` | 105 |
| `no` | 34 |

All 150 questions align exactly with the internal retrieval run, all KB IDs
are valid against the 89-entry frozen catalogue, and the KB hash is
`6539aef64f7a0e3c9b5b5f76d8b0015d4825967dc90c74a8855cd2b8d50e6290`.

## Retrieval metrics on final gold

The 116 cases with at least one relevant KB ID are scored with multi-label
Hit@k, Recall@k, and MRR. The 34 `coverage=no` cases are evaluated separately
for abstention at the production threshold of 0.22.

| Metric | Value |
|---|---:|
| Hit@1 | 0.509 |
| Hit@3 | 0.776 |
| Hit@5 | 0.845 |
| Recall@1 | 0.175 |
| Recall@3 | 0.349 |
| Recall@5 | 0.432 |
| MRR | 0.652 |
| Correct abstention | 2/34 (5.9%) |

Bootstrap percentile 95% intervals (10,000 resamples, seed 20260902) are
Hit@1 [0.414, 0.595], Hit@5 [0.776, 0.905], and MRR [0.583, 0.718]. The low
abstention rate indicates over-retrieval on questions judged outside the KB.
These are retrieval diagnostics, not answer-correctness or safety scores.
