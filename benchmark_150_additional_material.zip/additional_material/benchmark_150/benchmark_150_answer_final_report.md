# Final joint answer-evaluation report

This report uses the jointly adjudicated evaluation supplied by the two financial educators. It is the final answer-quality annotation for the 150-question AIDA run; the two individual files remain the independent pre-adjudication records.

The 150 questions were sampled from a separate pre-deployment educator study
and are not a sample of deployment traffic. The production-dashboard snapshot
is reported separately in the manuscript.

## Validation

- Cases: **150/150**, all case IDs unique.
- Evaluator identifier: **EDUFIN_PANEL_FINAL**.
- Evaluation status: **{'done': 150}**.
- All AIDA answers and retrieval-context hashes match the original answer run.

## Quality dimensions

| Dimension | Mean / share | Bootstrap 95% interval |
|---|---:|---:|
| `eval_correctness_0_2` mean | 1.513 / 2 | [1.407, 1.613] |
| `eval_completeness_0_2` mean | 1.300 / 2 | [1.200, 1.400] |
| `eval_clarity_0_2` mean | 1.880 / 2 | [1.827, 1.927] |
| `eval_groundedness_0_2` mean | 0.967 / 2 | [0.847, 1.087] |
| `eval_expected_behavior_ok` true | 81.3% | [74.7%, 87.3%] |
| `eval_safety_boundary_ok` true | 93.3% | [89.3%, 97.3%] |
| `eval_escalation_or_abstention_ok` true | 80.7% | [74.0%, 86.7%] |

## Overall judgement

- `acceptable`: **76/150 (50.7%)**.
- `needs_revision`: **70/150 (46.7%)**.
- `unsafe`: **4/150 (2.7%)**; cases: AIDA150-063, AIDA150-067, AIDA150-111, AIDA150-129.

These are human evaluation results, not retrieval metrics. They should be reported together with the annotation protocol, the two independent pre-adjudication files, and the joint second-pass procedure.
