#!/usr/bin/env python3
"""Compare the local Qwen judge with the final joint educator audit."""

from __future__ import annotations

import argparse
import csv
import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any


def kappa(left: list[str], right: list[str]) -> float:
    if len(left) != len(right) or not left:
        return float("nan")
    n = len(left)
    po = sum(a == b for a, b in zip(left, right)) / n
    cats = sorted(set(left) | set(right))
    p_left = Counter(left)
    p_right = Counter(right)
    pe = sum((p_left[c] / n) * (p_right[c] / n) for c in cats)
    return 1.0 if pe == 1.0 else (po - pe) / (1.0 - pe)


def confusion(left: list[str], right: list[str]) -> dict[str, dict[str, int]]:
    out: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))
    for a, b in zip(left, right):
        out[a][b] += 1
    return {k: dict(sorted(v.items())) for k, v in sorted(out.items())}


def read(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--local", type=Path, required=True)
    parser.add_argument("--educator", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    args = parser.parse_args()

    local = {r["case_id"]: r for r in read(args.local)}
    educator = {r["case_id"]: r for r in read(args.educator)}
    ids = sorted(set(local) & set(educator), key=lambda x: int(x.rsplit("-", 1)[1]))
    rows = [local[i] for i in ids if local[i].get("judge3_status") == "ok"]
    edu = [educator[i] for i in ids if local[i].get("judge3_status") == "ok"]

    result: dict[str, Any] = {
        "local_model": rows[0].get("judge3_model", "") if rows else "",
        "local_provider": rows[0].get("judge3_provider", "") if rows else "",
        "overlap_n": len(rows),
        "sampling_note": "deterministic stratified 50-case subset; educator scores were not shown to the local judge",
        "independence_note": "Qwen open-source checkpoint from a different model/provider family, executed locally",
        "numeric": {},
        "categorical": {},
        "unsafe_cases_local": [r["case_id"] for r in rows if r.get("judge3_overall_label") == "unsafe"],
        "unsafe_cases_educator": [r["case_id"] for r in edu if r.get("eval_overall_label") == "unsafe"],
    }

    for name in ["correctness", "completeness", "clarity", "groundedness"]:
        left = [int(r[f"judge3_{name}_0_2"]) for r in rows]
        right = [int(r[f"eval_{name}_0_2"]) for r in edu]
        result["numeric"][name] = {
            "local_mean": round(sum(left) / len(left), 4),
            "educator_mean": round(sum(right) / len(right), 4),
            "exact_agreement": round(sum(a == b for a, b in zip(left, right)) / len(left), 4),
            "mean_absolute_difference": round(sum(abs(a - b) for a, b in zip(left, right)) / len(left), 4),
            "unweighted_kappa": round(kappa([str(x) for x in left], [str(x) for x in right]), 4),
        }

    categorical = {
        "expected_behavior_ok": ("judge3_expected_behavior_ok", "eval_expected_behavior_ok"),
        "safety_boundary_ok": ("judge3_safety_boundary_ok", "eval_safety_boundary_ok"),
        "escalation_or_abstention_ok": ("judge3_escalation_or_abstention_ok", "eval_escalation_or_abstention_ok"),
        "overall_label": ("judge3_overall_label", "eval_overall_label"),
    }
    for name, (left_key, right_key) in categorical.items():
        left = [r[left_key] for r in rows]
        right = [e[right_key] for e in edu]
        if name != "overall_label":
            right = [{"true": "yes", "false": "no"}.get(x, x) for x in right]
        result["categorical"][name] = {
            "exact_agreement": round(sum(a == b for a, b in zip(left, right)) / len(left), 4),
            "unweighted_kappa": round(kappa(left, right), 4),
            "local_counts": dict(sorted(Counter(left).items())),
            "educator_counts": dict(sorted(Counter(right).items())),
            "confusion_local_rows_educator_columns": confusion(left, right),
        }

    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    lines = [
        "# Local Qwen judge cross-check",
        "",
        f"Overlap: **{result['overlap_n']}** cases from the deterministic stratified subset.",
        f"Judge: **{result['local_model']}** ({result['local_provider']}).",
        "",
        "The local judge did not receive educator outcome scores. It is a model-based sensitivity cross-check, not a replacement for the joint educator audit. The checkpoint belongs to a different open-source model/provider family from the Gemini-based judge and was executed locally.",
        "",
        "## Numeric dimensions",
        "",
        "| Dimension | Local-judge mean | Educator mean | Exact agreement | Mean absolute difference | κ |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for name, m in result["numeric"].items():
        lines.append(f"| {name} | {m['local_mean']:.3f} | {m['educator_mean']:.3f} | {m['exact_agreement']:.1%} | {m['mean_absolute_difference']:.3f} | {m['unweighted_kappa']:.3f} |")
    lines += ["", "## Categorical dimensions", "", "| Dimension | Exact agreement | κ |", "|---|---:|---:|"]
    for name, m in result["categorical"].items():
        lines.append(f"| {name} | {m['exact_agreement']:.1%} | {m['unweighted_kappa']:.3f} |")
    local_unsafe = ", ".join(result["unsafe_cases_local"]) or "none"
    educator_unsafe = ", ".join(result["unsafe_cases_educator"]) or "none"
    lines += ["", "Unsafe labels in the overlap: local judge `" + local_unsafe + "`; educators `" + educator_unsafe + "`.", ""]
    args.markdown.write_text("\n".join(lines), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
