#!/usr/bin/env python3
"""Retry only failed rows from the second-model audit and merge them."""

from __future__ import annotations

import argparse
import csv
import json
import time
from pathlib import Path

import run_second_llm_judge as base


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--model", default="gemini-3.1-pro-preview")
    parser.add_argument("--env-file", type=Path, default=Path("/Users/Fabio_Dadda/Desktop/edufin-new/Edufin/.env"))
    parser.add_argument("--max-attempts", type=int, default=5)
    parser.add_argument("--timeout", type=float, default=180.0)
    parser.add_argument("--cooldown", type=float, default=1.0)
    args = parser.parse_args()

    with args.input.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    failed = [row for row in rows if row.get("judge2_status") != "ok"]
    endpoint, model = base.resolve_api_endpoint(args.env_file, args.model)
    attempts_total = 0
    for index, row in enumerate(failed, start=1):
        last_error = ""
        for attempt in range(1, args.max_attempts + 1):
            attempts_total += 1
            try:
                payload = {
                    "contents": [{"role": "user", "parts": [{"text": base.judge_prompt(row)}]}],
                    "generationConfig": {
                        "temperature": 0.0,
                        "maxOutputTokens": 2200,
                        "responseMimeType": "application/json",
                        "responseSchema": {
                            "type": "OBJECT",
                            "properties": {
                                "correctness": {"type": "INTEGER"},
                                "completeness": {"type": "INTEGER"},
                                "clarity": {"type": "INTEGER"},
                                "groundedness": {"type": "INTEGER"},
                                "expected_behavior_ok": {"type": "STRING", "enum": ["yes", "no", "unclear"]},
                                "safety_boundary_ok": {"type": "STRING", "enum": ["yes", "no", "na"]},
                                "escalation_or_abstention_ok": {"type": "STRING", "enum": ["yes", "no", "na"]},
                                "overall_label": {"type": "STRING", "enum": ["acceptable", "needs_revision", "unsafe"]},
                                "error_or_omission": {"type": "STRING"},
                                "notes": {"type": "STRING"},
                            },
                            "required": [
                                "correctness", "completeness", "clarity", "groundedness",
                                "expected_behavior_ok", "safety_boundary_ok", "escalation_or_abstention_ok",
                                "overall_label", "error_or_omission", "notes",
                            ],
                        },
                    },
                }
                response = base.post_json(endpoint, payload, args.timeout)
                judgement = base.validate_judgement(json.loads(base.extract_json_text(response)))
                row.update({
                    "judge2_model": model,
                    "judge2_provider": "Google Gemini API",
                    "judge2_status": "ok",
                    "judge2_attempt": attempt,
                    "judge2_completed_at": base.utc_now(),
                    "judge2_correctness_0_2": judgement["correctness"],
                    "judge2_completeness_0_2": judgement["completeness"],
                    "judge2_clarity_0_2": judgement["clarity"],
                    "judge2_groundedness_0_2": judgement["groundedness"],
                    "judge2_expected_behavior_ok": judgement["expected_behavior_ok"],
                    "judge2_safety_boundary_ok": judgement["safety_boundary_ok"],
                    "judge2_escalation_or_abstention_ok": judgement["escalation_or_abstention_ok"],
                    "judge2_overall_label": judgement["overall_label"],
                    "judge2_error_or_omission": judgement["error_or_omission"],
                    "judge2_notes": judgement["notes"],
                    "judge2_error": "",
                })
                break
            except Exception as exc:  # retry transient/format failures
                last_error = f"{type(exc).__name__}: {exc}"[:2000]
                if attempt < args.max_attempts:
                    time.sleep(min(2 ** (attempt - 1), 12.0))
        if row.get("judge2_status") != "ok":
            row["judge2_error"] = last_error
            row["judge2_attempt"] = args.max_attempts
        print(f"[{index}/{len(failed)}] {row['case_id']} {row.get('judge2_status')} attempt={row.get('judge2_attempt')}", flush=True)
        if args.cooldown and index < len(failed):
            time.sleep(args.cooldown)

    fields = list(rows[0].keys())
    base.write_csv(args.input, rows, fields)
    report = json.loads(args.report.read_text(encoding="utf-8"))
    ok_rows = [row for row in rows if row.get("judge2_status") == "ok"]
    report.update({
        "model": model,
        "cases_ok": len(ok_rows),
        "cases_failed": len(rows) - len(ok_rows),
        "retry_attempts_total": attempts_total,
        "retry_completed_at": base.utc_now(),
        "response_schema_used_on_retry": True,
    })
    args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
