# Retriever ablation and threshold sensitivity

Post-hoc analysis on the adjudicated 150-question final gold. No LLM generation call or new annotation was used.

- Final gold: 116 covered/partial and 34 no-coverage cases.
- KB: 89 entries; SHA-256 6539aef64f7a0e3c9b5b5f76d8b0015d4825967dc90c74a8855cd2b8d50e6290.
- Hit/Recall/MRR use the 116 covered/partial cases; abstention and context metrics use all 150 cases.

## Ablation

| Variant | Hit@1 | Hit@3 | Hit@5 | Recall@5 | MRR | Correct abstention | False abstention | Mean selected | Context Hit@5 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| full_production | 0.509 | 0.776 | 0.845 | 0.432 | 0.652 | 2/34 (5.882%) | 6/116 (5.172%) | 1.467 | 0.569 |
| base_phrase_overlap | 0.466 | 0.638 | 0.716 | 0.355 | 0.579 | 13/34 (38.235%) | 41/116 (35.345%) | 0.833 | 0.388 |
| no_token_similarity | 0.491 | 0.741 | 0.819 | 0.396 | 0.639 | 2/34 (5.882%) | 8/116 (6.897%) | 1.313 | 0.543 |
| no_field_bonuses | 0.483 | 0.638 | 0.724 | 0.358 | 0.596 | 12/34 (35.294%) | 30/116 (25.862%) | 0.967 | 0.448 |

`full_production` reproduces the paper's final-gold Hit@5 (0.845), MRR (0.652), and correct abstention (2/34). `base_phrase_overlap` removes all additive bonuses. `no_token_similarity` removes the character-bigram Dice token match but retains phrase similarity and bonuses. `no_field_bonuses` removes acronym, keyword, and definition contributions while retaining term/query containment bonuses.

## Sensitivity of the low confidence floor

| Setting | Low floor | Medium | High | Context Hit@5 | Context Recall@5 | Correct abstention | False abstention | Mean selected |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| floor_0.18 | 0.180 | 0.420 | 0.700 | 0.569 | 0.237 | 0/34 (0.000%) | 1/116 (0.862%) | 1.573 |
| floor_0.22 | 0.220 | 0.420 | 0.700 | 0.569 | 0.237 | 2/34 (5.882%) | 6/116 (5.172%) | 1.467 |
| floor_0.26 | 0.260 | 0.420 | 0.700 | 0.560 | 0.234 | 3/34 (8.823%) | 12/116 (10.345%) | 1.393 |
| floor_0.30 | 0.300 | 0.420 | 0.700 | 0.543 | 0.228 | 4/34 (11.765%) | 15/116 (12.931%) | 1.360 |
| floor_0.35 | 0.350 | 0.420 | 0.700 | 0.526 | 0.222 | 9/34 (26.471%) | 26/116 (22.414%) | 1.207 |

## Three-threshold presets

| Preset | Low floor | Medium | High | Context Hit@5 | Context Recall@5 | Correct abstention | False abstention | Mean selected |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| preset_conservative | 0.260 | 0.460 | 0.750 | 0.560 | 0.231 | 3/34 (8.823%) | 12/116 (10.345%) | 1.353 |
| preset_production | 0.220 | 0.420 | 0.700 | 0.569 | 0.237 | 2/34 (5.882%) | 6/116 (5.172%) | 1.467 |
| preset_permissive | 0.180 | 0.380 | 0.650 | 0.569 | 0.237 | 0/34 (0.000%) | 1/116 (0.862%) | 1.633 |

## Interpretation

The analysis is post-hoc and descriptive: the final gold file is reused for every variant, so no setting should be presented as tuned or selected for deployment. Ablations identify which feature groups affect the frozen-KB ranking. Threshold sweeps identify the coverage--abstention trade-off at the prompt boundary; they do not estimate production prevalence. The no-coverage stratum is deliberately enriched and must not be read as a traffic rate.
