#!/usr/bin/env python3
"""Run the independent answer audit with a local quantized Qwen checkpoint.

The checkpoint is loaded through Apple MLX.  The input subset, rubric and
schema are the same as the other model-based cross-check; educator outcomes
are not supplied to the model.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from datetime import UTC, datetime
from pathlib import Path

from mlx_lm import load, generate
from mlx_lm.sample_utils import make_sampler

import run_second_llm_judge as rubric


def utc_now() -> str:
    return datetime.now(UTC).isoformat()


def parse_json(text: str) -> dict:
    start = text.find("{")
    if start < 0:
        raise ValueError("nessun oggetto JSON nella risposta")
    value, _ = json.JSONDecoder().raw_decode(text[start:])
    return value


def run(args: argparse.Namespace) -> None:
    rows = rubric.read_csv(args.input)
    subset = rubric.choose_subset(rows, args.sample_size, args.seed)
    model, tokenizer = load(str(args.model_path))
    sampler = make_sampler(temp=0.0)
    run_id = f"local-qwen-judge-{args.seed}"
    results: list[dict[str, str]] = []
    attempts_total = 0

    for index, row in enumerate(subset, start=1):
        out = dict(row)
        out.update({
            "judge3_model": args.model_id,
            "judge3_provider": "local open-source (Qwen; Apple MLX)",
            "judge3_run_id": run_id,
            "judge3_seed": args.seed,
            "judge3_sample_size": args.sample_size,
            "judge3_status": "error",
            "judge3_attempt": "",
            "judge3_completed_at": "",
            "judge3_correctness_0_2": "",
            "judge3_completeness_0_2": "",
            "judge3_clarity_0_2": "",
            "judge3_groundedness_0_2": "",
            "judge3_expected_behavior_ok": "",
            "judge3_safety_boundary_ok": "",
            "judge3_escalation_or_abstention_ok": "",
            "judge3_overall_label": "",
            "judge3_error_or_omission": "",
            "judge3_notes": "",
            "judge3_error": "",
        })
        last_error = ""
        for attempt in range(1, args.max_attempts + 1):
            attempts_total += 1
            try:
                generated = generate(
                    model,
                    tokenizer,
                    prompt=rubric.judge_prompt(row),
                    max_tokens=args.max_new_tokens,
                    sampler=sampler,
                    verbose=False,
                )
                judgement = rubric.validate_judgement(parse_json(generated))
                out.update({
                    "judge3_status": "ok",
                    "judge3_attempt": attempt,
                    "judge3_completed_at": utc_now(),
                    "judge3_correctness_0_2": judgement["correctness"],
                    "judge3_completeness_0_2": judgement["completeness"],
                    "judge3_clarity_0_2": judgement["clarity"],
                    "judge3_groundedness_0_2": judgement["groundedness"],
                    "judge3_expected_behavior_ok": judgement["expected_behavior_ok"],
                    "judge3_safety_boundary_ok": judgement["safety_boundary_ok"],
                    "judge3_escalation_or_abstention_ok": judgement["escalation_or_abstention_ok"],
                    "judge3_overall_label": judgement["overall_label"],
                    "judge3_error_or_omission": judgement["error_or_omission"],
                    "judge3_notes": judgement["notes"],
                    "judge3_error": "",
                })
                break
            except Exception as exc:  # malformed output is retried
                last_error = f"{type(exc).__name__}: {exc}"[:2000]
        if out["judge3_status"] != "ok":
            out.update({
                "judge3_attempt": args.max_attempts,
                "judge3_completed_at": utc_now(),
                "judge3_error": last_error,
            })
        results.append(out)
        print(
            f"[{index}/{len(subset)}] {row['case_id']} "
            f"{out['judge3_status']} attempt={out['judge3_attempt']}",
            flush=True,
        )

    fields = list(rows[0].keys()) + [
        "judge3_model", "judge3_provider", "judge3_run_id", "judge3_seed", "judge3_sample_size",
        "judge3_status", "judge3_attempt", "judge3_completed_at", "judge3_correctness_0_2",
        "judge3_completeness_0_2", "judge3_clarity_0_2", "judge3_groundedness_0_2",
        "judge3_expected_behavior_ok", "judge3_safety_boundary_ok", "judge3_escalation_or_abstention_ok",
        "judge3_overall_label", "judge3_error_or_omission", "judge3_notes", "judge3_error",
    ]
    rubric.write_csv(args.output, results, fields)
    ok = [r for r in results if r["judge3_status"] == "ok"]
    report = {
        "run_id": run_id,
        "created_at": utc_now(),
        "model": args.model_id,
        "model_path": str(args.model_path),
        "provider": "local open-source (Qwen; Apple MLX)",
        "independence": "different model and provider family from Gemini production/RAGAS judges; executed locally",
        "input_file": str(args.input),
        "input_sha256": hashlib.sha256(args.input.read_bytes()).hexdigest(),
        "output_file": str(args.output),
        "cases_available": len(rows),
        "cases_sampled": len(subset),
        "cases_ok": len(ok),
        "cases_failed": len(subset) - len(ok),
        "seed": args.seed,
        "sampling": "stratified by expert_expected_behavior; deterministic SHA-256 ranking within strata",
        "strata_sampled": {
            k: sum(r.get("expert_expected_behavior") == k for r in subset)
            for k in sorted({r.get("expert_expected_behavior") for r in subset})
        },
        "attempts_total": attempts_total,
        "credentials_included": False,
        "local_execution": True,
        "score_fields": [
            "correctness", "completeness", "clarity", "groundedness",
            "expected_behavior_ok", "safety_boundary_ok", "escalation_or_abstention_ok", "overall_label",
        ],
    }
    args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--model-path", type=Path, required=True)
    parser.add_argument("--model-id", default="Qwen2.5-7B-Instruct-4bit")
    parser.add_argument("--sample-size", type=int, default=50)
    parser.add_argument("--seed", type=int, default=20260903)
    parser.add_argument("--max-attempts", type=int, default=3)
    parser.add_argument("--max-new-tokens", type=int, default=400)
    args = parser.parse_args()
    run(args)


if __name__ == "__main__":
    main()
