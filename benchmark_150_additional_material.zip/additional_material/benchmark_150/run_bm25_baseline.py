#!/usr/bin/env python3
"""Reproduce a default BM25 baseline on the adjudicated AIDA-150 retrieval set.

The benchmark is intentionally not used to tune BM25 parameters. The baseline
indexes each KB entry's term, acronym, keywords, and definition as one document,
uses the original question as the query, and abstains only when the best score
is exactly zero. Per-case output omits question text.
"""

from __future__ import annotations

import csv
import json
import math
import random
import re
import unicodedata
from collections import Counter
from pathlib import Path


HERE = Path(__file__).resolve().parent
K1 = 1.5
B = 0.75
BOOTSTRAP_SEED = 20260904
BOOTSTRAP_SAMPLES = 10_000


def read_csv(filename: str) -> list[dict[str, str]]:
    with (HERE / filename).open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def tokens(text: str) -> list[str]:
    normalized = unicodedata.normalize("NFKD", text.casefold())
    plain = "".join(char for char in normalized if not unicodedata.combining(char))
    return re.findall(r"[a-z0-9]+", plain)


def percentile(sorted_values: list[float], probability: float) -> float:
    position = (len(sorted_values) - 1) * probability
    lower = math.floor(position)
    upper = math.ceil(position)
    if lower == upper:
        return sorted_values[lower]
    weight = position - lower
    return sorted_values[lower] * (1 - weight) + sorted_values[upper] * weight


def mean(values: list[float]) -> float:
    return sum(values) / len(values) if values else float("nan")


def bootstrap_ci(values: list[float], rng: random.Random) -> list[float]:
    samples = sorted(
        mean([values[rng.randrange(len(values))] for _ in values])
        for _ in range(BOOTSTRAP_SAMPLES)
    )
    return [round(percentile(samples, 0.025), 4), round(percentile(samples, 0.975), 4)]


def bootstrap_ratio_ci(numerators: list[int], denominators: list[int], rng: random.Random) -> list[float]:
    samples = []
    for _ in range(BOOTSTRAP_SAMPLES):
        indices = [rng.randrange(len(numerators)) for _ in numerators]
        denominator = sum(denominators[index] for index in indices)
        numerator = sum(numerators[index] for index in indices)
        samples.append(numerator / denominator if denominator else 0.0)
    samples.sort()
    return [round(percentile(samples, 0.025), 4), round(percentile(samples, 0.975), 4)]


def bm25_scores(query: list[str], documents: list[list[str]]) -> list[float]:
    document_count = len(documents)
    lengths = [len(document) for document in documents]
    average_length = mean([float(length) for length in lengths])
    frequencies = [Counter(document) for document in documents]
    document_frequency = Counter(
        token for document in documents for token in set(document)
    )
    unique_query_terms = set(query)
    scores = [0.0] * document_count

    for token in unique_query_terms:
        df = document_frequency.get(token, 0)
        if df == 0:
            continue
        # Robertson--Walker IDF with the standard positive offset.
        idf = math.log(1 + (document_count - df + 0.5) / (df + 0.5))
        for index, term_frequencies in enumerate(frequencies):
            tf = term_frequencies.get(token, 0)
            if not tf:
                continue
            length_norm = K1 * (1 - B + B * lengths[index] / average_length)
            scores[index] += idf * (tf * (K1 + 1)) / (tf + length_norm)
    return scores


def item_metrics(ranked_ids: list[str], gold_ids: set[str]) -> dict[str, float]:
    if not gold_ids:
        return {}
    reciprocal_rank = 0.0
    for rank, kb_id in enumerate(ranked_ids, start=1):
        if kb_id in gold_ids:
            reciprocal_rank = 1 / rank
            break
    top5 = set(ranked_ids[:5])
    return {
        "hit_at_1": float(bool(set(ranked_ids[:1]) & gold_ids)),
        "hit_at_3": float(bool(set(ranked_ids[:3]) & gold_ids)),
        "hit_at_5": float(bool(top5 & gold_ids)),
        "recall_at_5_numerator": len(top5 & gold_ids),
        "recall_at_5_denominator": len(gold_ids),
        "mrr": reciprocal_rank,
    }


def main() -> None:
    catalogue = read_csv("benchmark_150_kb_catalog.csv")
    gold_rows = read_csv("benchmark_150_final_gold.csv")
    production_rows = {
        row["case_id"]: row
        for row in read_csv("benchmark_150_retrieval_internal.csv")
    }

    documents = [
        tokens(" ".join(row.get(field, "") for field in ("term", "acronym", "keywords", "definition")))
        for row in catalogue
    ]
    ids = [row["kb_id"] for row in catalogue]
    items: list[dict[str, object]] = []

    for row in gold_rows:
        case_id = row["case_id"]
        question = row["question_original"]
        bm25 = bm25_scores(tokens(question), documents)
        bm25_order = sorted(range(len(ids)), key=lambda index: (-bm25[index], ids[index]))
        bm25_ranked_ids = [ids[index] for index in bm25_order]
        production = production_rows[case_id]
        production_all = json.loads(production["all_scores_json"])
        production_ranked_ids = [
            value["kb_id"]
            for value in sorted(
                production_all,
                key=lambda value: -float(value["score"]),
            )
        ]
        gold_value = row["expert_relevant_kb_ids"].strip()
        gold_ids = set() if gold_value in {"", "NONE"} else {
            item.strip() for item in gold_value.split("|") if item.strip()
        }
        covered = row["expert_kb_coverage"] in {"yes", "partial"}
        if covered != bool(gold_ids):
            raise ValueError(f"Coverage/gold-ID mismatch for {case_id}")
        if not gold_ids and row["expert_kb_coverage"] != "no":
            raise ValueError(f"Unexpected empty gold set for {case_id}")

        items.append({
            "case_id": case_id,
            "covered": covered,
            "gold_ids": gold_ids,
            "bm25_ids": bm25_ranked_ids,
            "production_ids": production_ranked_ids,
            "bm25_best_score": max(bm25),
            "bm25_no_match": max(bm25) == 0,
            "production_no_match": not production["best_match_id"],
        })

    covered_items = [item for item in items if item["covered"]]
    no_coverage_items = [item for item in items if not item["covered"]]
    metric_names = ("hit_at_1", "hit_at_3", "hit_at_5", "recall_at_5", "mrr")
    observed: dict[str, dict[str, dict[str, object]]] = {}
    metric_vectors: dict[str, dict[str, list[float]]] = {}

    for method in ("bm25", "production"):
        rows = [item_metrics(item[f"{method}_ids"], item["gold_ids"]) for item in covered_items]
        vectors = {
            name: [float(row[name]) for row in rows]
            for name in metric_names if name != "recall_at_5"
        }
        metric_vectors[method] = vectors
        observed[method] = {}
        for index, name in enumerate(metric_names):
            if name == "recall_at_5":
                numerators = [int(row["recall_at_5_numerator"]) for row in rows]
                denominators = [int(row["recall_at_5_denominator"]) for row in rows]
                estimate = sum(numerators) / sum(denominators)
                interval = bootstrap_ratio_ci(
                    numerators, denominators, random.Random(BOOTSTRAP_SEED + index)
                )
            else:
                estimate = mean(vectors[name])
                interval = bootstrap_ci(vectors[name], random.Random(BOOTSTRAP_SEED + index))
            observed[method][name] = {
                "estimate": round(estimate, 4),
                "bootstrap_95_ci": interval,
            }

    # Paired resampling uses the same sampled cases for both retrieval methods.
    paired_rng = random.Random(BOOTSTRAP_SEED + 100)
    paired_differences: dict[str, list[float]] = {"hit_at_5": [], "mrr": []}
    for _ in range(BOOTSTRAP_SAMPLES):
        indices = [paired_rng.randrange(len(covered_items)) for _ in covered_items]
        for metric in paired_differences:
            bm25_mean = mean([metric_vectors["bm25"][metric][i] for i in indices])
            production_mean = mean([metric_vectors["production"][metric][i] for i in indices])
            paired_differences[metric].append(bm25_mean - production_mean)
    paired_ci = {
        metric: {
            "mean_difference_bm25_minus_production": round(mean(values), 4),
            "paired_bootstrap_95_ci": [
                round(percentile(sorted(values), 0.025), 4),
                round(percentile(sorted(values), 0.975), 4),
            ],
        }
        for metric, values in paired_differences.items()
    }

    bm25_correct_abstention = sum(bool(item["bm25_no_match"]) for item in no_coverage_items)
    bm25_false_abstention = sum(bool(item["bm25_no_match"]) for item in covered_items)
    production_correct_abstention = sum(bool(item["production_no_match"]) for item in no_coverage_items)
    production_false_abstention = sum(bool(item["production_no_match"]) for item in covered_items)

    report = {
        "benchmark": "AIDA-150 final joint educator gold",
        "catalogue_entries": len(catalogue),
        "covered_or_partial_cases": len(covered_items),
        "no_coverage_cases": len(no_coverage_items),
        "protocol": {
            "bm25_variant": "Okapi BM25 with Robertson--Walker positive-offset IDF",
            "k1": K1,
            "b": B,
            "document_fields": ["term", "acronym", "keywords", "definition"],
            "field_weights": "one concatenated document; no field boosts",
            "tokenization": "Unicode NFKD accent folding, casefold, alphanumeric tokens",
            "stopwords_or_stemming": "none",
            "query": "original question text",
            "tie_break": "ascending KB ID",
            "abstention": "best BM25 score equals zero (no query-token match)",
            "production_abstention": "production best_match_id is empty below the 0.22 reliable floor",
            "bootstrap": {
                "method": "case-level percentile bootstrap",
                "samples": BOOTSTRAP_SAMPLES,
                "seed": BOOTSTRAP_SEED,
            },
        },
        "metrics_on_covered_or_partial_cases": observed,
        "abstention": {
            "bm25": {
                "correct": bm25_correct_abstention,
                "correct_denominator": len(no_coverage_items),
                "false": bm25_false_abstention,
                "false_denominator": len(covered_items),
            },
            "production": {
                "correct": production_correct_abstention,
                "correct_denominator": len(no_coverage_items),
                "false": production_false_abstention,
                "false_denominator": len(covered_items),
            },
        },
        "paired_differences_bm25_minus_production": paired_ci,
    }
    (HERE / "benchmark_150_bm25_baseline_report.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )

    with (HERE / "benchmark_150_bm25_baseline_per_case.csv").open(
        "w", encoding="utf-8-sig", newline=""
    ) as stream:
        writer = csv.DictWriter(
            stream,
            fieldnames=[
                "case_id", "coverage", "gold_kb_ids", "bm25_top5_kb_ids",
                "bm25_best_score", "bm25_no_match_abstention", "production_top5_kb_ids",
            ],
            lineterminator="\n",
        )
        writer.writeheader()
        for item in items:
            writer.writerow({
                "case_id": item["case_id"],
                "coverage": "covered_or_partial" if item["covered"] else "no_coverage",
                "gold_kb_ids": " | ".join(sorted(item["gold_ids"])) or "NONE",
                "bm25_top5_kb_ids": " | ".join(item["bm25_ids"][:5]),
                "bm25_best_score": f"{item['bm25_best_score']:.8f}",
                "bm25_no_match_abstention": item["bm25_no_match"],
                "production_top5_kb_ids": " | ".join(item["production_ids"][:5]),
            })

    print(json.dumps(report, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
