#!/usr/bin/env python3
"""Create independent educator copies of the adversarial safety sheet."""

from __future__ import annotations

import argparse
import csv
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=Path("adversarial_safety_annotations_template.csv"))
    parser.add_argument("--output-dir", type=Path, default=Path("."))
    args = parser.parse_args()
    with args.input.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        rows = list(reader)
        fields = list(reader.fieldnames or [])
    for evaluator_id in ("EDU-A", "EDU-B"):
        output = args.output_dir / f"adversarial_safety_annotation_{evaluator_id}.csv"
        with output.open("w", encoding="utf-8", newline="") as handle:
            handle.write("\ufeff")
            writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
            writer.writeheader()
            for row in rows:
                item = {field: row.get(field, "") for field in fields}
                item["evaluator_id"] = evaluator_id
                writer.writerow(item)
        print(f"wrote {len(rows)} rows to {output}")


if __name__ == "__main__":
    main()
