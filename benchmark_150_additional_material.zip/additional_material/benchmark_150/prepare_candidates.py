#!/usr/bin/env python3
"""Prepare a blinded candidate set from the pre-deployment educator study for the AIDA benchmark.

The script deliberately does not use the automatic retrieval result to write
the annotator-facing file. It uses retrieval confidence only to balance the
sampling strata; the actual retrieved entries are produced by the separate
Node harness and kept in the internal output.
"""

from __future__ import annotations

import csv
import hashlib
import json
import re
import unicodedata
from collections import defaultdict
from datetime import datetime
from pathlib import Path


CSV_SOURCE = Path("/Users/Fabio_Dadda/Downloads/export-domande-risposte-completo.csv")
OUT_DIR = Path(__file__).resolve().parent
OUT_DIR.mkdir(parents=True, exist_ok=True)


def normalise(text: str) -> str:
    value = unicodedata.normalize("NFKC", text or "").lower().strip()
    value = re.sub(r"\s+", " ", value)
    value = re.sub(r"[^\w\sàèéìòù]", "", value)
    return value


def redact(text: str) -> str:
    value = text or ""
    # Remove common self-identification patterns before the file is shared
    # with annotators. The raw export remains untouched outside this output.
    value = re.sub(
        r"\b(mi chiamo|sono)\s+[A-ZÀ-ÖØ-Ý][a-zà-öø-ÿ]+(?:\s+[A-ZÀ-ÖØ-Ý][a-zà-öø-ÿ]+){0,2}",
        r"\1 [PERSONA]",
        value,
    )
    value = re.sub(r"[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}", "[EMAIL]", value, flags=re.I)
    value = re.sub(r"(?<!\d)(?:\+?39[\s.-]?)?(?:\d[\s.-]?){8,}\d(?!\d)", "[PHONE]", value)
    value = re.sub(r"\bIT\d{2}[A-Z]?\d{10,30}\b", "[IBAN]", value, flags=re.I)
    value = re.sub(r"\b[A-Z]{6}\d{2}[A-Z]\d{2}[A-Z]\d{3}[A-Z]\b", "[TAX_ID]", value, flags=re.I)
    return value.strip()


def parse_dt(value: str) -> datetime:
    try:
        return datetime.fromisoformat((value or "").replace("Z", "+00:00"))
    except ValueError:
        return datetime.min


def domain(text: str) -> str:
    value = normalise(text)
    buckets = [
        # Put the most specific application areas first. Generic words such as
        # "rischio" or "finanziario" occur in almost every topic and would
        # otherwise swallow the useful domain labels.
        ("educazione_aief", r"aief|educatore|registro educatori|albo|corso|formazione|associazione|universita"),
        ("finanziamenti", r"mutuo|prestito|finanziament|taeg|tan|rata|debito|credito|fido"),
        ("fiscalita", r"tass|fisco|irpef|minus|plusvalenz|agenzia delle entrate|isee|lordo"),
        ("previdenza", r"pension|previdenz|fondo pension|tfr|tfm|contribut|inps"),
        ("protezione", r"assicur|ivass|polizza|fitd|depositi|garanzia"),
        ("conti_pagamenti", r"conto corrente|carta|bancomat|pagamento|banca|bonifico"),
        ("cripto_mercati", r"bitcoin|crypto|criptovalut|satoshi|default|economia|inflazion|moneta"),
        ("investimenti", r"azioni|obbligaz|etf|oicr|fondo|titoli|borsa|invest|rendimento|benchmark"),
    ]
    for name, pattern in buckets:
        if re.search(pattern, value):
            return name
    return "altro"


def has_numeric_signal(text: str) -> bool:
    value = text or ""
    return bool(re.search(r"(?:\d|%|€|euro|taeg|tan|tfr|28\s*anni|300)", value, flags=re.I))


def safety_signal(text: str) -> bool:
    value = normalise(text)
    return bool(
        re.search(
            r"consigli|mi conviene|cosa compro|come investo|quanto invest|mio stipendio|mio reddito|"
            r"miei risparmi|situazione personale|prodotto specific|garant|sicuro|consulenza|"
            r"non pago|posso recuperare|ricorso|patentino|fuori sede",
            value,
        )
    )


def eligible(question: str) -> bool:
    value = " ".join((question or "").split())
    n = normalise(value)
    if len(n) < 22:
        return False
    # Stand-alone demographic fragments are useful conversation context but
    # are not self-contained benchmark questions.
    if re.match(r"^(ho|sono)\s+\d+\s+anni\b", n):
        return False
    # Short noun phrases are usually UI selections or topic labels rather
    # than benchmark questions (for example "European Investment Practitioner").
    if len(n.split()) <= 4 and not re.search(
        r"\b(come|cosa|cos|che|chi|quale|quali|quanto|posso|puo|può|perche|perché|dove|"
        r"perche|conviene|spieg|differenza|funzion|serve|esiste|vorrei|mi|devo)\b",
        n,
    ):
        return False
    if n in {
        "si",
        "no",
        "piu dettagli",
        "e tutto qui",
        "sii piu specifico",
        "spaghetti",
        "lella",
        "nunzio lella",
        "di cosa parli",
    }:
        return False
    if n in {"risparmioinvestimenti", "previdenza", "protezione", "finanziamenti"}:
        return False
    return True


def row_key(row: dict[str, str]) -> tuple[str, str]:
    return normalise(row.get("domanda", "")), row.get("chat_id", "")


def main() -> None:
    with CSV_SOURCE.open(encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle, delimiter=";"))

    # First remove exact/near-exact duplicate prompts, preferring rows with a
    # feedback signal and then the earliest occurrence.
    unique: dict[str, dict[str, str]] = {}
    for row in sorted(rows, key=lambda item: parse_dt(item.get("data_domanda", ""))):
        question = " ".join((row.get("domanda") or "").split())
        if not eligible(question):
            continue
        key = normalise(question)
        if key not in unique:
            unique[key] = row
        elif row.get("feedback") and not unique[key].get("feedback"):
            unique[key] = row

    candidates = []
    for key, row in unique.items():
        question = " ".join((row.get("domanda") or "").split())
        # Keep at most the two preceding user prompts from the same chat as
        # optional context. The current retriever itself receives only the
        # current question in the first benchmark pass.
        candidates.append(
            {
                "question": redact(question),
                "original_question_hash": hashlib.sha256(question.encode("utf-8")).hexdigest()[:16],
                "chat_hash": hashlib.sha256((row.get("chat_id") or "").encode("utf-8")).hexdigest()[:16],
                "data_domanda": row.get("data_domanda", ""),
                "domain": domain(question),
                "numeric_signal": has_numeric_signal(question),
                "safety_signal": safety_signal(question),
                "feedback_internal": (row.get("feedback") or "").strip(),
                "source_row_hash": hashlib.sha256(
                    (row.get("chat_id", "") + "|" + row.get("message_id_risposta", "") + "|" + question).encode("utf-8")
                ).hexdigest()[:16],
            }
        )

    # Stable ordering keeps the candidate file reproducible.
    candidates.sort(key=lambda item: (item["data_domanda"], item["original_question_hash"]))

    # Save the broad pool for the retrieval harness. It will select the final
    # 150 after running the actual Edufin confidence function.
    (OUT_DIR / "candidate_pool.json").write_text(
        json.dumps(candidates, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps({"input_rows": len(rows), "eligible_unique_candidates": len(candidates)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
