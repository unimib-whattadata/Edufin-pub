#!/usr/bin/env python3
"""Run a frozen multilingual E5 dense-retrieval baseline on AIDA-150.

No question text is written to the per-case output. The benchmark is not used
to tune the model or any retrieval parameter. Embeddings are computed locally.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import random
from pathlib import Path
from typing import Any

import numpy as np
import sentence_transformers
import torch
import transformers
from sentence_transformers import SentenceTransformer

from run_bm25_baseline import bm25_scores, tokens


HERE = Path(__file__).resolve().parent
MODEL_ID = "intfloat/multilingual-e5-small"
MODEL_REVISION = "614241f622f53c4eeff9890bdc4f31cfecc418b3"
RRF_K = 60
BOOTSTRAP_SEED = 20260904
BOOTSTRAP_SAMPLES = 10_000


def read_csv(filename: str) -> list[dict[str, str]]:
    with (HERE / filename).open("r", encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def mean(values: list[float]) -> float:
    return sum(values) / len(values) if values else float("nan")


def percentile(sorted_values: list[float], probability: float) -> float:
    position = (len(sorted_values) - 1) * probability
    lower = math.floor(position)
    upper = math.ceil(position)
    if lower == upper:
        return sorted_values[lower]
    weight = position - lower
    return sorted_values[lower] * (1 - weight) + sorted_values[upper] * weight


def bootstrap_ci(values: list[float], seed: int) -> list[float]:
    rng = random.Random(seed)
    samples = sorted(
        mean([values[rng.randrange(len(values))] for _ in values])
        for _ in range(BOOTSTRAP_SAMPLES)
    )
    return [round(percentile(samples, 0.025), 4), round(percentile(samples, 0.975), 4)]


def bootstrap_ratio_ci(numerators: list[int], denominators: list[int], seed: int) -> list[float]:
    rng = random.Random(seed)
    samples = []
    for _ in range(BOOTSTRAP_SAMPLES):
        indices = [rng.randrange(len(numerators)) for _ in numerators]
        denominator = sum(denominators[index] for index in indices)
        numerator = sum(numerators[index] for index in indices)
        samples.append(numerator / denominator if denominator else 0.0)
    samples.sort()
    return [round(percentile(samples, 0.025), 4), round(percentile(samples, 0.975), 4)]


def item_metrics(ranked_ids: list[str], gold_ids: set[str]) -> dict[str, float | int]:
    reciprocal_rank = 0.0
    for rank, kb_id in enumerate(ranked_ids, start=1):
        if kb_id in gold_ids:
            reciprocal_rank = 1 / rank
            break
    top5 = set(ranked_ids[:5])
    return {
        "hit_at_1": float(bool(set(ranked_ids[:1]) & gold_ids)),
        "hit_at_3": float(bool(set(ranked_ids[:3]) & gold_ids)),
        "hit_at_5": float(bool(top5 & gold_ids)),
        "recall_at_5_numerator": len(top5 & gold_ids),
        "recall_at_5_denominator": len(gold_ids),
        "mrr": reciprocal_rank,
    }


def vector_metrics(items: list[dict[str, Any]], method: str) -> dict[str, list[float]]:
    vectors: dict[str, list[float]] = {
        metric: [] for metric in ("hit_at_1", "hit_at_3", "hit_at_5", "mrr")
    }
    for item in items:
        observed = item_metrics(item[f"{method}_ids"], item["gold_ids"])
        for metric in vectors:
            vectors[metric].append(float(observed[metric]))
    return vectors


def summarize_metrics(items: list[dict[str, Any]], method: str) -> dict[str, Any]:
    vectors = vector_metrics(items, method)
    result: dict[str, Any] = {}
    for offset, metric in enumerate(("hit_at_1", "hit_at_3", "hit_at_5", "mrr")):
        values = vectors[metric]
        result[metric] = {
            "estimate": round(mean(values), 4),
            "bootstrap_95_ci": bootstrap_ci(values, BOOTSTRAP_SEED + offset),
        }
    ratios = [item_metrics(item[f"{method}_ids"], item["gold_ids"]) for item in items]
    numerators = [int(row["recall_at_5_numerator"]) for row in ratios]
    denominators = [int(row["recall_at_5_denominator"]) for row in ratios]
    result["recall_at_5"] = {
        "estimate": round(sum(numerators) / sum(denominators), 4),
        "bootstrap_95_ci": bootstrap_ratio_ci(
            numerators, denominators, BOOTSTRAP_SEED + 4
        ),
    }
    return result


def paired_difference(
    items: list[dict[str, Any]], left: str, right: str, metric: str
) -> dict[str, Any]:
    left_values = vector_metrics(items, left)[metric]
    right_values = vector_metrics(items, right)[metric]
    differences = [a - b for a, b in zip(left_values, right_values)]
    rng = random.Random(BOOTSTRAP_SEED + 100)
    samples = sorted(
        mean([differences[rng.randrange(len(differences))] for _ in differences])
        for _ in range(BOOTSTRAP_SAMPLES)
    )
    return {
        f"mean_difference_{left}_minus_{right}": round(mean(differences), 4),
        "paired_bootstrap_95_ci": [
            round(percentile(samples, 0.025), 4),
            round(percentile(samples, 0.975), 4),
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-report", type=Path, default=HERE / "benchmark_150_e5_dense_baseline_report.json")
    parser.add_argument("--output-csv", type=Path, default=HERE / "benchmark_150_e5_dense_baseline_per_case.csv")
    parser.add_argument("--model", default=MODEL_ID)
    parser.add_argument("--revision", default=MODEL_REVISION)
    parser.add_argument("--local-files-only", action="store_true")
    args = parser.parse_args()

    catalogue = read_csv("benchmark_150_kb_catalog.csv")
    gold_rows = read_csv("benchmark_150_final_gold.csv")
    production_rows = {
        row["case_id"]: row for row in read_csv("benchmark_150_retrieval_internal.csv")
    }
    documents = [
        "passage: " + " ".join(
            row.get(field, "").strip()
            for field in ("term", "acronym", "keywords", "definition")
            if row.get(field, "").strip()
        )
        for row in catalogue
    ]
    kb_ids = [row["kb_id"] for row in catalogue]
    bm25_documents = [
        tokens(" ".join(row.get(field, "") for field in ("term", "acronym", "keywords", "definition")))
        for row in catalogue
    ]
    model = SentenceTransformer(
        args.model,
        revision=args.revision,
        device="cpu",
        local_files_only=args.local_files_only,
    )
    document_vectors = model.encode(
        documents,
        batch_size=32,
        show_progress_bar=False,
        convert_to_numpy=True,
        normalize_embeddings=True,
    )

    items: list[dict[str, Any]] = []
    output_rows: list[dict[str, str]] = []
    for gold in gold_rows:
        case_id = gold["case_id"]
        query_vector = model.encode(
            "query: " + gold["question_original"],
            show_progress_bar=False,
            convert_to_numpy=True,
            normalize_embeddings=True,
        )
        scores = np.asarray(document_vectors @ query_vector, dtype=np.float64)
        ordering = sorted(range(len(kb_ids)), key=lambda index: (-scores[index], kb_ids[index]))
        ranked_ids = [kb_ids[index] for index in ordering]
        gold_value = gold["expert_relevant_kb_ids"].strip()
        relevant_ids = set() if gold_value in {"", "NONE"} else {
            item.strip() for item in gold_value.split("|") if item.strip()
        }
        covered = gold["expert_kb_coverage"] in {"yes", "partial"}
        if covered != bool(relevant_ids):
            raise ValueError(f"Coverage/gold-ID mismatch for {case_id}")
        if not relevant_ids and gold["expert_kb_coverage"] != "no":
            raise ValueError(f"Unexpected empty gold set for {case_id}")

        production = production_rows[case_id]
        production_all = json.loads(production["all_scores_json"])
        production_ids = [
            value["kb_id"] for value in sorted(production_all, key=lambda value: -float(value["score"]))
        ]
        bm25_rank_scores = bm25_scores(tokens(gold["question_original"]), bm25_documents)
        bm25_ordering = sorted(range(len(kb_ids)), key=lambda index: (-bm25_rank_scores[index], kb_ids[index]))
        bm25_ids = [kb_ids[index] for index in bm25_ordering]
        rrf_scores = [0.0] * len(kb_ids)
        for rank, index in enumerate(bm25_ordering, start=1):
            rrf_scores[index] += 1 / (RRF_K + rank)
        for rank, index in enumerate(ordering, start=1):
            rrf_scores[index] += 1 / (RRF_K + rank)
        hybrid_ordering = sorted(range(len(kb_ids)), key=lambda index: (-rrf_scores[index], kb_ids[index]))
        hybrid_ids = [kb_ids[index] for index in hybrid_ordering]
        if covered:
            items.append({
                "case_id": case_id,
                "gold_ids": relevant_ids,
                "e5_ids": ranked_ids,
                "production_ids": production_ids,
                "bm25_ids": bm25_ids,
                "hybrid_ids": hybrid_ids,
            })
        top5_positions = ordering[:5]
        item_result = item_metrics(ranked_ids, relevant_ids) if covered else {}
        hybrid_result = item_metrics(hybrid_ids, relevant_ids) if covered else {}
        output_rows.append({
            "case_id": case_id,
            "expert_coverage": gold["expert_kb_coverage"],
            "expert_relevant_kb_ids": "|".join(sorted(relevant_ids)),
            "e5_hit_at_1": str(int(item_result.get("hit_at_1", 0))),
            "e5_hit_at_3": str(int(item_result.get("hit_at_3", 0))),
            "e5_hit_at_5": str(int(item_result.get("hit_at_5", 0))),
            "e5_recall_at_5_numerator": str(int(item_result.get("recall_at_5_numerator", 0))),
            "e5_recall_at_5_denominator": str(int(item_result.get("recall_at_5_denominator", 0))),
            "e5_mrr": f"{float(item_result.get('mrr', 0)):.6f}",
            "e5_top5_kb_ids": "|".join(kb_ids[index] for index in top5_positions),
            "e5_top5_cosine_scores": "|".join(f"{scores[index]:.6f}" for index in top5_positions),
            "rrf_hybrid_hit_at_5": str(int(hybrid_result.get("hit_at_5", 0))),
            "rrf_hybrid_recall_at_5_numerator": str(int(hybrid_result.get("recall_at_5_numerator", 0))),
            "rrf_hybrid_recall_at_5_denominator": str(int(hybrid_result.get("recall_at_5_denominator", 0))),
            "rrf_hybrid_mrr": f"{float(hybrid_result.get('mrr', 0)):.6f}",
            "rrf_hybrid_top5_kb_ids": "|".join(kb_ids[index] for index in hybrid_ordering[:5]),
            "rrf_hybrid_top5_scores": "|".join(f"{rrf_scores[index]:.8f}" for index in hybrid_ordering[:5]),
            "abstention": "not_evaluated; no calibrated threshold",
        })

    methods = {
        "multilingual_e5_small": summarize_metrics(items, "e5"),
        "rrf_hybrid_bm25_plus_e5": summarize_metrics(items, "hybrid"),
        "production": summarize_metrics(items, "production"),
        "bm25": summarize_metrics(items, "bm25"),
    }
    report = {
        "benchmark": "AIDA-150 final joint educator gold",
        "catalogue_entries": len(catalogue),
        "covered_or_partial_cases": len(items),
        "no_coverage_cases": len(gold_rows) - len(items),
        "protocol": {
            "model": args.model,
            "model_revision": args.revision,
            "embedding_dimension": int(document_vectors.shape[1]),
            "runtime": {
                "sentence_transformers": sentence_transformers.__version__,
                "transformers": transformers.__version__,
                "torch": torch.__version__,
                "device": "cpu",
            },
            "query_text": "query: " + "<original Italian question>",
            "document_text": "passage: " + "term + acronym + keywords + definition concatenated in KB field order",
            "similarity": "cosine via dot product of L2-normalized embeddings",
            "training_or_tuning": "none; frozen checkpoint and default ranking; no fit on audit labels",
            "hybrid": {
                "method": "equal-weight reciprocal-rank fusion of full BM25 and multilingual E5 rankings",
                "rrf_k": RRF_K,
                "tuning": "none; fixed standard rank-fusion constant, no fit on audit labels",
            },
            "tie_break": "ascending KB ID",
            "abstention": "not evaluated; dense scores were not calibrated to the production confidence floor",
            "bootstrap": {
                "method": "case-level percentile bootstrap",
                "samples": BOOTSTRAP_SAMPLES,
                "seed": BOOTSTRAP_SEED,
            },
            "sample_selection_note": "The stratified AIDA-150 sample was selected partly using production-confidence signals; these post-hoc comparisons are descriptive and may favor the deployed retriever.",
        },
        "metrics_on_covered_or_partial_cases": methods,
        "paired_differences": {
            "e5_minus_production": {
                metric: paired_difference(items, "e5", "production", metric)
                for metric in ("hit_at_5", "mrr")
            },
            "e5_minus_bm25": {
                metric: paired_difference(items, "e5", "bm25", metric)
                for metric in ("hit_at_5", "mrr")
            },
            "hybrid_minus_production": {
                metric: paired_difference(items, "hybrid", "production", metric)
                for metric in ("hit_at_5", "mrr")
            },
            "hybrid_minus_bm25": {
                metric: paired_difference(items, "hybrid", "bm25", metric)
                for metric in ("hit_at_5", "mrr")
            },
        },
    }

    args.output_csv.parent.mkdir(parents=True, exist_ok=True)
    args.output_report.parent.mkdir(parents=True, exist_ok=True)
    with args.output_csv.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(output_rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(output_rows)
    args.output_report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
